import React from 'react'

const UpdateBlogData = () => {
  return (
    <div>
      
    </div>
  )
}

export default UpdateBlogData
