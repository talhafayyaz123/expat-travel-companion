"use client";

import { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CloudIcon } from "lucide-react";
import {
  blogPostSchema,
  BlogPostFormData,
} from "../../../../../../../schema/blogSchema";
import { useUpdateBlogMutation, useSingleBlogQuery } from "@/redux/Api/blogApi";
import { toast } from "sonner";
import { useParams, useRouter } from "next/navigation";
import Loader from "@/app/loading";
import { Blog } from "@/types/Blog";
import ReactQuill from "react-quill-new";
import "react-quill/dist/quill.bubble.css";
import "react-quill-new/dist/quill.snow.css";
import { formats, modules } from "@/constants/editorData";
import Image from "next/image";

export default function UpdateBlogPost() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [isEditingImage, setIsEditingImage] = useState(false);
  const router = useRouter();

  const { blogId } = useParams<{ blogId: string }>();

  interface SingleDataResponse {
    success: boolean;
    statusCode: number;
    message: string;
    data: Blog;
    isLoading: boolean;
  }

  const { data: singleBlogData, isLoading: singleBlogLoading } =
    useSingleBlogQuery<SingleDataResponse>(blogId);

  console.log(singleBlogData);

  const [updateBlog] = useUpdateBlogMutation();

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<BlogPostFormData>({});

  const [contentValue, setContentValue] = useState("");
  // Update form values when singleBlogData is loaded
  useEffect(() => {
    if (singleBlogData?.data) {
      const { country, content, services, title } = singleBlogData.data;
      reset({
        country,
        content,
        banner: undefined,
        services,
        title,
      });
      setContentValue(content);
    }
  }, [singleBlogData, reset]);

  const [preview, setPreview] = useState(true);

  const onSubmit = async (data: BlogPostFormData) => {
    setIsSubmitting(true);
    const formData = new FormData();

    try {
      const newData = {
        country: data.country,
        services: data.services,
        title: data.title,
        content: contentValue,
      };
      formData.append("data", JSON.stringify(newData));
      if (data.banner && data.banner[0]) {
        formData.append(
          "banner",
          data.banner && data.banner[0] ? data.banner[0] : ""
        );
      }

      console.log(formData);
      await updateBlog({ id: blogId, formData }).unwrap();
      toast.success("Blog updated successfully");
      router.push("/dashboard/admin/blogs");
      router.refresh();
      reset();
    } catch (error) {
      console.error("Error updating blog post:", error);
      toast.error("Failed to update the blog post");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (singleBlogLoading) {
    return <Loader />;
  }

  // const blogDatas=singleBlogData?.data as Blog
  return (
    <div className="container mx-auto p-4">
      <Card className="max-w-3xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Update Blog Post</CardTitle>
          <p className="text-sm text-muted-foreground">
            Update your blog post details and content here.
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
              {/* Banner */}
              <Label>Post Banner</Label>
              <div className="relative">
                <div className="border-2 border-dashed rounded-lg p-8">
                  <div className="flex flex-col items-center justify-center gap-2">
                    {singleBlogData?.data?.banner && !isEditingImage ? (
                      <>
                        {/* <div className="relative">
                         <Image src={singleBlogData.data.banner} alt="" className="size-full" fill />
                        </div> */}
                        <img
                          className="h-[300px] w-full"
                          src={singleBlogData.data.banner}
                          alt=""
                        />
                        <Button
                          type="button"
                          variant="outline"
                          className="absolute top-2 right-2"
                          onClick={() => setIsEditingImage(true)}
                        >
                          Edit Image
                        </Button>
                      </>
                    ) : (
                      <>
                        <CloudIcon className="h-8 w-8 text-muted-foreground" />
                        <label
                          htmlFor="banner"
                          className="cursor-pointer text-blue-500 hover:underline"
                        >
                          Browse
                        </label>
                        <input
                          type="file"
                          id="banner"
                          className="hidden"
                          accept="image/*"
                          {...register("banner", {
                            onChange: (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                setFileName(file.name);
                              }
                            },
                          })}
                        />
                        {fileName && (
                          <p className="text-sm text-green-600">
                            File selected: {fileName}
                          </p>
                        )}
                      </>
                    )}
                  </div>
                </div>
                {errors.banner && (
                  <p className="text-sm text-red-500">
                    {errors.banner.message}
                  </p>
                )}
              </div>
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Controller
                  name="country"
                  control={control}
                  render={({ field }) => (
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <SelectTrigger id="country" disabled>
                        <SelectValue placeholder="Select country" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="UAE">UAE</SelectItem>
                        <SelectItem value="USA">USA</SelectItem>
                        <SelectItem value="UK">UK</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                />
                {errors.country && (
                  <p className="text-sm text-red-500">
                    {errors.country.message}
                  </p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="services">Services</Label>
                <Input
                  id="services"
                  {...register("services")}
                  placeholder="Enter your services"
                />
                {errors.services && (
                  <p className="text-sm text-red-500">
                    {errors.services.message}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">Blog Title</Label>
              <Input
                id="title"
                {...register("title")}
                placeholder="Enter your blog title"
              />
              {errors.title && (
                <p className="text-sm text-red-500">{errors.title.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Blog Content</Label>

              <ReactQuill
                value={contentValue}
                onChange={(e) => setContentValue(e)}
                modules={modules}
                className=""
                formats={formats}
                theme="snow"
              />

              {errors.content && (
                <p className="text-sm text-red-500">{errors.content.message}</p>
              )}
            </div>

            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Updating..." : "Update Blog Post"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
