(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(default)_membership_page_tsx_c68074._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(default)_membership_page_tsx_c68074._.js",
  "chunks": [
    "static/chunks/src_7f741c._.js",
    "static/chunks/node_modules_e5dd42._.js"
  ],
  "source": "dynamic"
});
