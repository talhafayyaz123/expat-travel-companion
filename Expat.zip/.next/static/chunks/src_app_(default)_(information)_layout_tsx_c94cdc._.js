(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(default)_(information)_layout_tsx_c94cdc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(default)_(information)_layout_tsx_c94cdc._.js",
  "chunks": [
    "static/chunks/src_3d64eb._.js"
  ],
  "source": "dynamic"
});
