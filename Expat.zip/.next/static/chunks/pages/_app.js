__turbopack_load_page_chunks__("/_app", [
  "static/chunks/[root of the server]__14669f._.js",
  "static/chunks/node_modules_react_b2385d._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e07.js",
  "static/chunks/node_modules_react-dom_f14d04._.js",
  "static/chunks/node_modules_69e050._.js",
  "static/chunks/[root of the server]__f265a1._.js",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_77f66c._.js"
])
