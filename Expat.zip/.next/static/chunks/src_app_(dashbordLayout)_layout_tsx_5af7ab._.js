(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(dashbordLayout)_layout_tsx_5af7ab._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(dashbordLayout)_layout_tsx_5af7ab._.js",
  "chunks": [
    "static/chunks/node_modules_859c68._.js",
    "static/chunks/src_d9c299._.js"
  ],
  "source": "dynamic"
});
