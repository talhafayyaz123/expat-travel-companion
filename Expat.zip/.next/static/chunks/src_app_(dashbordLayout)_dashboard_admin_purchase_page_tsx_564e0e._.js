(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(dashbordLayout)_dashboard_admin_purchase_page_tsx_5728ad._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(dashbordLayout)_dashboard_admin_purchase_page_tsx_5728ad._.js",
  "chunks": [
    "static/chunks/src_ee5e74._.js",
    "static/chunks/node_modules_chart_js_dist_10c9ba._.js",
    "static/chunks/node_modules_react-icons_lia_index_mjs_8eda93._.js",
    "static/chunks/node_modules_react-icons_sl_index_mjs_f0cdce._.js",
    "static/chunks/node_modules_react-icons_go_index_mjs_af0fd2._.js",
    "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856._.js",
    "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e7.js",
    "static/chunks/node_modules_cefa2b._.js",
    "static/chunks/src_components_admin_purchase-history_chartStyle_81d267.css",
    "static/chunks/node_modules_49ae81._.js"
  ],
  "source": "dynamic"
});
