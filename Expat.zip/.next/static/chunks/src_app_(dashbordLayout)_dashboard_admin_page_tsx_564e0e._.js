(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(dashbordLayout)_dashboard_admin_page_tsx_5728ad._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(dashbordLayout)_dashboard_admin_page_tsx_5728ad._.js",
  "chunks": [
    "static/chunks/src_5caf0e._.js",
    "static/chunks/node_modules_react-icons_io5_index_mjs_39106f._.js",
    "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856._.js",
    "static/chunks/node_modules_xlsx_xlsx_mjs_ad7550._.js",
    "static/chunks/node_modules_date-fns_f5d2ca._.js",
    "static/chunks/node_modules_@floating-ui_react_dist_c1a64d._.js",
    "static/chunks/node_modules_react-datepicker_dist_index_es_28f28d.js",
    "static/chunks/node_modules_5a88b2._.js",
    "static/chunks/node_modules_react-datepicker_dist_react-datepicker_a24da8.css",
    "static/chunks/src_components_ui_dialog_tsx_19cd81._.js"
  ],
  "source": "dynamic"
});
