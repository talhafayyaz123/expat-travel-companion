(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(default)_profile-details_[id]_page_tsx_c68074._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(default)_profile-details_[id]_page_tsx_c68074._.js",
  "chunks": [
    "static/chunks/src_195cd0._.js",
    "static/chunks/node_modules_9383b5._.js"
  ],
  "source": "dynamic"
});
