(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(default)_search-filter_page_tsx_c94cdc._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(default)_search-filter_page_tsx_c94cdc._.js",
  "chunks": [
    "static/chunks/src_1a4994._.js",
    "static/chunks/node_modules_32079a._.js",
    "static/chunks/node_modules_yet-another-react-lightbox_dist_styles_163b51.css"
  ],
  "source": "dynamic"
});
