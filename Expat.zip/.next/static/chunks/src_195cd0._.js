(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_195cd0._.js", {

"[project]/src/redux/Api/destinationApi.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "useDeleteDestMutation": (()=>useDeleteDestMutation),
    "useDestinationAddMutation": (()=>useDestinationAddMutation),
    "useGetDestinationQuery": (()=>useGetDestinationQuery),
    "useGetSingleDesQuery": (()=>useGetSingleDesQuery),
    "useGetSingleUserDesQuery": (()=>useGetSingleUserDesQuery),
    "useUpdateDestMutation": (()=>useUpdateDestMutation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/baseApi.ts [app-client] (ecmascript)");
;
const userApi = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].injectEndpoints({
    endpoints: (build)=>({
            destinationAdd: build.mutation({
                query: (data)=>{
                    return {
                        url: "/destination",
                        method: "POST",
                        body: data
                    };
                },
                invalidatesTags: [
                    "AllDestination"
                ]
            }),
            getDestination: build.query({
                query: ()=>{
                    return {
                        url: "destination/my-destination",
                        method: "GET"
                    };
                },
                providesTags: [
                    "AllDestination",
                    "User"
                ]
            }),
            getSingleDes: build.query({
                query: (destinationId)=>({
                        url: `destination/${destinationId}`,
                        method: "GET"
                    }),
                providesTags: [
                    "AllDestination"
                ]
            }),
            updateDest: build.mutation({
                query: (updateData)=>({
                        url: `destination/${updateData.id}`,
                        method: "PUT",
                        body: {
                            travelType: updateData.travelType,
                            TravelBegins: updateData.TravelBegins,
                            destinationCountry: updateData.destinationCountry,
                            destinationCity: updateData.destinationCity
                        },
                        invalidatesTags: [
                            "AllDestination"
                        ]
                    })
            }),
            getSingleUserDes: build.query({
                query: (destinationId)=>({
                        url: `destination/user/${destinationId}`,
                        method: "GET"
                    }),
                providesTags: [
                    "AllDestination",
                    "User"
                ]
            }),
            deleteDest: build.mutation({
                query: (destinationId)=>({
                        url: `destination/${destinationId}`,
                        method: "DELETE"
                    }),
                invalidatesTags: [
                    "AllDestination",
                    "User"
                ]
            })
        })
});
const { useDestinationAddMutation, useGetDestinationQuery, useGetSingleDesQuery, useUpdateDestMutation, useGetSingleUserDesQuery, useDeleteDestMutation } = userApi;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/userProfile/DestinationLoader.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "DestinationLoader": (()=>DestinationLoader)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const DestinationLoader = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full border border-solid border-gray-300 rounded-xl p-[14px]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-6 bg-gray-200 rounded w-1/2"
                            }, void 0, false, {
                                fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                                lineNumber: 9,
                                columnNumber: 7
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-gray-200 rounded w-16"
                            }, void 0, false, {
                                fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                                lineNumber: 10,
                                columnNumber: 7
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                        lineNumber: 8,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                        className: "bg-gray-300 mt-3"
                    }, void 0, false, {
                        fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                        lineNumber: 12,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-gray-200 rounded w-full mt-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                                lineNumber: 14,
                                columnNumber: 7
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-gray-200 rounded w-full mt-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                                lineNumber: 15,
                                columnNumber: 7
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-gray-200 rounded w-full mt-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                                lineNumber: 16,
                                columnNumber: 7
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-gray-200 rounded w-full mt-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                                lineNumber: 17,
                                columnNumber: 7
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-4 bg-gray-200 rounded w-full mt-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                                lineNumber: 18,
                                columnNumber: 7
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                        lineNumber: 13,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
                lineNumber: 7,
                columnNumber: 3
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
            lineNumber: 6,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/userProfile/DestinationLoader.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
};
_c = DestinationLoader;
var _c;
__turbopack_refresh__.register(_c, "DestinationLoader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/currentCountries.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "currentCountries": (()=>currentCountries)
});
const currentCountries = [
    {
        id: 1,
        label: "Afghanistan",
        value: "AF"
    },
    {
        id: 2,
        label: "Albania",
        value: "AL"
    },
    {
        id: 3,
        label: "Algeria",
        value: "DZ"
    },
    {
        id: 4,
        label: "American Samoa (US Territory)",
        value: "AS"
    },
    {
        id: 5,
        label: "Andorra",
        value: "AD"
    },
    {
        id: 6,
        label: "Angola",
        value: "AO"
    },
    {
        id: 7,
        label: "Antigua and Barbuda",
        value: "AG"
    },
    {
        id: 8,
        label: "Argentina",
        value: "AR"
    },
    {
        id: 9,
        label: "Armenia",
        value: "AM"
    },
    {
        id: 10,
        label: "Australia",
        value: "AU"
    },
    {
        id: 11,
        label: "Austria",
        value: "AT"
    },
    {
        id: 12,
        label: "Azerbaijan",
        value: "AZ"
    },
    {
        id: 13,
        label: "The Bahamas",
        value: "BS"
    },
    {
        id: 14,
        label: "Bahrain",
        value: "BH"
    },
    {
        id: 15,
        label: "Bangladesh",
        value: "BD"
    },
    {
        id: 16,
        label: "Barbados",
        value: "BB"
    },
    {
        id: 17,
        label: "Belarus",
        value: "BY"
    },
    {
        id: 18,
        label: "Belgium",
        value: "BE"
    },
    {
        id: 19,
        label: "Belize",
        value: "BZ"
    },
    {
        id: 20,
        label: "Benin",
        value: "BJ"
    },
    {
        id: 21,
        label: "Bhutan",
        value: "BT"
    },
    {
        id: 22,
        label: "Bolivia",
        value: "BO"
    },
    {
        id: 23,
        label: "Bosnia and Herzegovina",
        value: "BA"
    },
    {
        id: 24,
        label: "Botswana",
        value: "BW"
    },
    {
        id: 25,
        label: "Brazil",
        value: "BR"
    },
    {
        id: 26,
        label: "Brunei",
        value: "BN"
    },
    {
        id: 27,
        label: "Bulgaria",
        value: "BG"
    },
    {
        id: 28,
        label: "Burkina Faso",
        value: "BF"
    },
    {
        id: 29,
        label: "Burundi",
        value: "BI"
    },
    {
        id: 30,
        label: "Cabo Verde",
        value: "CV"
    },
    {
        id: 31,
        label: "Cambodia",
        value: "KH"
    },
    {
        id: 32,
        label: "Cameroon",
        value: "CM"
    },
    {
        id: 33,
        label: "Canada",
        value: "CA"
    },
    {
        id: 34,
        label: "Central African Republic",
        value: "CF"
    },
    {
        id: 35,
        label: "Chad",
        value: "TD"
    },
    {
        id: 36,
        label: "Chile",
        value: "CL"
    },
    {
        id: 37,
        label: "China",
        value: "CN"
    },
    {
        id: 38,
        label: "Colombia",
        value: "CO"
    },
    {
        id: 39,
        label: "Comoros",
        value: "KM"
    },
    {
        id: 40,
        label: "Congo, Democratic Republic of the",
        value: "CD"
    },
    {
        id: 41,
        label: "Congo, Republic of the",
        value: "CG"
    },
    {
        id: 42,
        label: "Costa Rica",
        value: "CR"
    },
    {
        id: 43,
        label: "Côte d'Ivoire",
        value: "CI"
    },
    {
        id: 44,
        label: "Croatia",
        value: "HR"
    },
    {
        id: 45,
        label: "Cuba",
        value: "CU"
    },
    {
        id: 46,
        label: "Cyprus",
        value: "CY"
    },
    {
        id: 47,
        label: "Czech Republic",
        value: "CZ"
    },
    {
        id: 48,
        label: "Denmark",
        value: "DK"
    },
    {
        id: 49,
        label: "Djibouti",
        value: "DJ"
    },
    {
        id: 50,
        label: "Dominica",
        value: "DM"
    },
    {
        id: 51,
        label: "Dominican Republic",
        value: "DO"
    },
    {
        id: 52,
        label: "East Timor (Timor-Leste)",
        value: "TL"
    },
    {
        id: 53,
        label: "Ecuador",
        value: "EC"
    },
    {
        id: 54,
        label: "Egypt",
        value: "EG"
    },
    {
        id: 55,
        label: "El Salvador",
        value: "SV"
    },
    {
        id: 56,
        label: "Equatorial Guinea",
        value: "GQ"
    },
    {
        id: 57,
        label: "Eritrea",
        value: "ER"
    },
    {
        id: 58,
        label: "Estonia",
        value: "EE"
    },
    {
        id: 59,
        label: "Eswatini",
        value: "SZ"
    },
    {
        id: 60,
        label: "Ethiopia",
        value: "ET"
    },
    {
        id: 61,
        label: "Fiji",
        value: "FJ"
    },
    {
        id: 62,
        label: "Finland",
        value: "FI"
    },
    {
        id: 63,
        label: "France",
        value: "FR"
    },
    {
        id: 64,
        label: "Gabon",
        value: "GA"
    },
    {
        id: 65,
        label: "The Gambia",
        value: "GM"
    },
    {
        id: 66,
        label: "Georgia",
        value: "GE"
    },
    {
        id: 67,
        label: "Germany",
        value: "DE"
    },
    {
        id: 68,
        label: "Ghana",
        value: "GH"
    },
    {
        id: 69,
        label: "Greece",
        value: "GR"
    },
    {
        id: 70,
        label: "Grenada",
        value: "GD"
    },
    {
        id: 71,
        label: "Guam (US Territory)",
        value: "GU"
    },
    {
        id: 72,
        label: "Guatemala",
        value: "GT"
    },
    {
        id: 73,
        label: "Guinea",
        value: "GN"
    },
    {
        id: 74,
        label: "Guinea-Bissau",
        value: "GW"
    },
    {
        id: 75,
        label: "Guyana",
        value: "GY"
    },
    {
        id: 76,
        label: "Haiti",
        value: "HT"
    },
    {
        id: 77,
        label: "Honduras",
        value: "HN"
    },
    {
        id: 78,
        label: "Hungary",
        value: "HU"
    },
    {
        id: 79,
        label: "Iceland",
        value: "IS"
    },
    {
        id: 80,
        label: "India",
        value: "IN"
    },
    {
        id: 81,
        label: "Indonesia",
        value: "ID"
    },
    {
        id: 82,
        label: "Iran",
        value: "IR"
    },
    {
        id: 83,
        label: "Iraq",
        value: "IQ"
    },
    {
        id: 84,
        label: "Ireland",
        value: "IE"
    },
    {
        id: 85,
        label: "Israel",
        value: "IL"
    },
    {
        id: 86,
        label: "Italy",
        value: "IT"
    },
    {
        id: 87,
        label: "Jamaica",
        value: "JM"
    },
    {
        id: 88,
        label: "Japan",
        value: "JP"
    },
    {
        id: 89,
        label: "Jordan",
        value: "JO"
    },
    {
        id: 90,
        label: "Kazakhstan",
        value: "KZ"
    },
    {
        id: 91,
        label: "Kenya",
        value: "KE"
    },
    {
        id: 92,
        label: "Kiribati",
        value: "KI"
    },
    {
        id: 93,
        label: "Korea, North",
        value: "KP"
    },
    {
        id: 94,
        label: "Korea, South",
        value: "KR"
    },
    {
        id: 95,
        label: "Kosovo",
        value: "XK"
    },
    {
        id: 96,
        label: "Kuwait",
        value: "KW"
    },
    {
        id: 97,
        label: "Kyrgyzstan",
        value: "KG"
    },
    {
        id: 98,
        label: "Laos",
        value: "LA"
    },
    {
        id: 99,
        label: "Latvia",
        value: "LV"
    },
    {
        id: 100,
        label: "Lebanon",
        value: "LB"
    },
    {
        id: 101,
        label: "Lesotho",
        value: "LS"
    },
    {
        id: 102,
        label: "Liberia",
        value: "LR"
    },
    {
        id: 103,
        label: "Libya",
        value: "LY"
    },
    {
        id: 104,
        label: "Liechtenstein",
        value: "LI"
    },
    {
        id: 105,
        label: "Lithuania",
        value: "LT"
    },
    {
        id: 106,
        label: "Luxembourg",
        value: "LU"
    },
    {
        id: 107,
        label: "Madagascar",
        value: "MG"
    },
    {
        id: 108,
        label: "Malawi",
        value: "MW"
    },
    {
        id: 109,
        label: "Malaysia",
        value: "MY"
    },
    {
        id: 110,
        label: "Maldives",
        value: "MV"
    },
    {
        id: 111,
        label: "Mali",
        value: "ML"
    },
    {
        id: 112,
        label: "Malta",
        value: "MT"
    },
    {
        id: 113,
        label: "Marshall Islands",
        value: "MH"
    },
    {
        id: 114,
        label: "Mauritania",
        value: "MR"
    },
    {
        id: 115,
        label: "Mauritius",
        value: "MU"
    },
    {
        id: 116,
        label: "Mexico",
        value: "MX"
    },
    {
        id: 117,
        label: "Micronesia, Federated States of",
        value: "FM"
    },
    {
        id: 118,
        label: "Moldova",
        value: "MD"
    },
    {
        id: 119,
        label: "Monaco",
        value: "MC"
    },
    {
        id: 120,
        label: "Mongolia",
        value: "MN"
    },
    {
        id: 121,
        label: "Montenegro",
        value: "ME"
    },
    {
        id: 122,
        label: "Morocco",
        value: "MA"
    },
    {
        id: 123,
        label: "Mozambique",
        value: "MZ"
    },
    {
        id: 124,
        label: "Myanmar (Burma)",
        value: "MM"
    },
    {
        id: 125,
        label: "Namibia",
        value: "NA"
    },
    {
        id: 126,
        label: "Nauru",
        value: "NR"
    },
    {
        id: 127,
        label: "Nepal",
        value: "NP"
    },
    {
        id: 128,
        label: "Netherlands",
        value: "NL"
    },
    {
        id: 129,
        label: "New Zealand",
        value: "NZ"
    },
    {
        id: 130,
        label: "Nicaragua",
        value: "NI"
    },
    {
        id: 131,
        label: "Niger",
        value: "NE"
    },
    {
        id: 132,
        label: "Nigeria",
        value: "NG"
    },
    {
        id: 133,
        label: "North Macedonia",
        value: "MK"
    },
    {
        id: 134,
        label: "Northern Mariana Islands (US Territory)",
        value: "MP"
    },
    {
        id: 135,
        label: "Norway",
        value: "NO"
    },
    {
        id: 136,
        label: "Oman",
        value: "OM"
    },
    {
        id: 137,
        label: "Pakistan",
        value: "PK"
    },
    {
        id: 138,
        label: "Palau",
        value: "PW"
    },
    {
        id: 139,
        label: "Panama",
        value: "PA"
    },
    {
        id: 140,
        label: "Papua New Guinea",
        value: "PG"
    },
    {
        id: 141,
        label: "Paraguay",
        value: "PY"
    },
    {
        id: 142,
        label: "Peru",
        value: "PE"
    },
    {
        id: 143,
        label: "Philippines",
        value: "PH"
    },
    {
        id: 144,
        label: "Poland",
        value: "PL"
    },
    {
        id: 145,
        label: "Portugal",
        value: "PT"
    },
    {
        id: 146,
        label: "Puerto Rico (US Territory)",
        value: "PR"
    },
    {
        id: 147,
        label: "Qatar",
        value: "QA"
    },
    {
        id: 148,
        label: "Romania",
        value: "RO"
    },
    {
        id: 149,
        label: "Russia",
        value: "RU"
    },
    {
        id: 150,
        label: "Rwanda",
        value: "RW"
    },
    {
        id: 151,
        label: "Saint Kitts and Nevis",
        value: "KN"
    },
    {
        id: 152,
        label: "Saint Lucia",
        value: "LC"
    },
    {
        id: 153,
        label: "Saint Vincent and the Grenadines",
        value: "VC"
    },
    {
        id: 154,
        label: "Samoa",
        value: "WS"
    },
    {
        id: 155,
        label: "San Marino",
        value: "SM"
    },
    {
        id: 156,
        label: "Sao Tome and Principe",
        value: "ST"
    },
    {
        id: 157,
        label: "Saudi Arabia",
        value: "SA"
    },
    {
        id: 158,
        label: "Senegal",
        value: "SN"
    },
    {
        id: 159,
        label: "Serbia",
        value: "RS"
    },
    {
        id: 160,
        label: "Seychelles",
        value: "SC"
    },
    {
        id: 161,
        label: "Sierra Leone",
        value: "SL"
    },
    {
        id: 162,
        label: "Singapore",
        value: "SG"
    },
    {
        id: 163,
        label: "Slovakia",
        value: "SK"
    },
    {
        id: 164,
        label: "Slovenia",
        value: "SI"
    },
    {
        id: 165,
        label: "Solomon Islands",
        value: "SB"
    },
    {
        id: 166,
        label: "Somalia",
        value: "SO"
    },
    {
        id: 167,
        label: "South Africa",
        value: "ZA"
    },
    {
        id: 168,
        label: "Spain",
        value: "ES"
    },
    {
        id: 169,
        label: "Sri Lanka",
        value: "LK"
    },
    {
        id: 170,
        label: "Sudan",
        value: "SD"
    },
    {
        id: 171,
        label: "Sudan, South",
        value: "SS"
    },
    {
        id: 172,
        label: "Suriname",
        value: "SR"
    },
    {
        id: 173,
        label: "Sweden",
        value: "SE"
    },
    {
        id: 174,
        label: "Switzerland",
        value: "CH"
    },
    {
        id: 175,
        label: "Syria",
        value: "SY"
    },
    {
        id: 176,
        label: "Taiwan",
        value: "TW"
    },
    {
        id: 177,
        label: "Tajikistan",
        value: "TJ"
    },
    {
        id: 178,
        label: "Tanzania",
        value: "TZ"
    },
    {
        id: 179,
        label: "Thailand",
        value: "TH"
    },
    {
        id: 180,
        label: "Togo",
        value: "TG"
    },
    {
        id: 181,
        label: "Tonga",
        value: "TO"
    },
    {
        id: 182,
        label: "Trinidad and Tobago",
        value: "TT"
    },
    {
        id: 183,
        label: "Tunisia",
        value: "TN"
    },
    {
        id: 184,
        label: "Turkey",
        value: "TR"
    },
    {
        id: 185,
        label: "Turkmenistan",
        value: "TM"
    },
    {
        id: 186,
        label: "Tuvalu",
        value: "TV"
    },
    {
        id: 187,
        label: "Uganda",
        value: "UG"
    },
    {
        id: 188,
        label: "Ukraine",
        value: "UA"
    },
    {
        id: 189,
        label: "United Arab Emirates",
        value: "AE"
    },
    {
        id: 190,
        label: "United Kingdom",
        value: "GB"
    },
    {
        id: 191,
        label: "United States",
        value: "US"
    },
    {
        id: 192,
        label: "Uruguay",
        value: "UY"
    },
    {
        id: 193,
        label: "Uzbekistan",
        value: "UZ"
    },
    {
        id: 194,
        label: "Vanuatu",
        value: "VU"
    },
    {
        id: 195,
        label: "Vatican City",
        value: "VA"
    },
    {
        id: 196,
        label: "Venezuela",
        value: "VE"
    },
    {
        id: 197,
        label: "Vietnam",
        value: "VN"
    },
    {
        id: 198,
        label: "Virgin Islands (British)",
        value: "VG"
    },
    {
        id: 199,
        label: "Virgin Islands (US)",
        value: "VI"
    },
    {
        id: 200,
        label: "Yemen",
        value: "YE"
    },
    {
        id: 201,
        label: "Zambia",
        value: "ZM"
    },
    {
        id: 202,
        label: "Zimbabwe",
        value: "ZW"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/countryOptions.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "allcountry": (()=>allcountry),
    "combinedCountryData": (()=>combinedCountryData),
    "combinedCountryDataWithAllCountry": (()=>combinedCountryDataWithAllCountry),
    "countryOptions": (()=>countryOptions),
    "getCountryLabel": (()=>getCountryLabel)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$currentCountries$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/constants/currentCountries.tsx [app-client] (ecmascript)");
;
const countryOptions = [
    {
        id: 240,
        label: "Cruise-Africa",
        value: "Cruise-Africa"
    },
    {
        id: 241,
        label: "Cruise-Alaska",
        value: "Cruise-Alaska"
    },
    {
        id: 242,
        label: "Cruise-Antarctica",
        value: "Cruise-Antarctica"
    },
    {
        id: 243,
        label: "Cruise-Asia",
        value: "Cruise-Asia"
    },
    {
        id: 244,
        label: "Cruise-Australia",
        value: "Cruise-Australia"
    },
    {
        id: 245,
        label: "Cruise-Caribbean & Mexico",
        value: "Cruise-Caribbean_&_Mexico"
    },
    {
        id: 246,
        label: "Cruise-Central America",
        value: "Cruise-Central_America"
    },
    {
        id: 247,
        label: "Cruise-Europe",
        value: "Cruise-Europe"
    },
    {
        id: 248,
        label: "Cruise-Europe Baltic Sea",
        value: "Cruise-Europe_Baltic_Sea"
    },
    {
        id: 249,
        label: "Cruise-Europe Mediterranean",
        value: "Cruise-Europe_Mediterranean"
    },
    {
        id: 250,
        label: "Cruise-Europe Northern Europe",
        value: "Cruise-Europe_Northern_Europe"
    },
    {
        id: 251,
        label: "Cruise-Hawaii",
        value: "Cruise-Hawaii"
    },
    {
        id: 252,
        label: "Cruise-North America",
        value: "Cruise-North_America"
    },
    {
        id: 253,
        label: "Cruise-South America",
        value: "Cruise-South_America"
    },
    {
        id: 254,
        label: "Cruise-World Cruises",
        value: "Cruise-World_Cruises"
    },
    {
        id: 255,
        label: "Cruise-Other",
        value: "Cruise-Other"
    }
];
const allcountry = [
    {
        id: 3000,
        label: "All Countries",
        value: "allCountries"
    }
];
const combinedCountryData = [
    ...countryOptions,
    ...allcountry,
    ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$currentCountries$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentCountries"]
];
const combinedCountryDataWithAllCountry = [
    ...allcountry,
    ...__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$currentCountries$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["currentCountries"]
];
const getCountryLabel = (countryValue)=>{
    const country = combinedCountryData.find((option)=>option.value == countryValue);
    return country?.label ? country.label : "N/A";
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/traveType.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
// export const travelOption = [
//   {
//     label: "Cruise",
//     value: "Cruise",
//   },
//   {
//     label: "Slow Travel (2 mo - 6 mo)",
//     value: "Slow_Travel_(2 mo - 6 mo)",
//   },
//   {
//     label: "Scouting Trip (1-8 wks)",
//     value: "Scouting_Trip_(1-8 wks)",
//   },
//   {
//     label: "Long Term (6 mo - 1 yr+)",
//     value: "Long_Term_(6 mo - 1 yr+)",
//   },
// ];
__turbopack_esm__({
    "getTravelTypeLabel": (()=>getTravelTypeLabel),
    "travelOption": (()=>travelOption)
});
const travelOption = [
    {
        label: "Cruise",
        value: "Cruise"
    },
    {
        label: "Slow Travel 2 - 6 mo",
        value: "SlowTravel"
    },
    {
        label: "Scouting Trip (1-8 wks)",
        value: "ScoutingTrip"
    },
    {
        label: "Long Term 6 mo - 1 yr",
        value: "LongTerm"
    }
];
const getTravelTypeLabel = (value)=>{
    const travelType = travelOption.find((option)=>option.value === value);
    return travelType ? travelType.label : "N/A";
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/profileDetails/ProfDetialsDest.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "ProfDetailsDest": (()=>ProfDetailsDest)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$destinationApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/destinationApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$DestinationLoader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/userProfile/DestinationLoader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$countryOptions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/constants/countryOptions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$traveType$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/constants/traveType.ts [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
;
;
;
;
const ProfDetailsDest = ()=>{
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const { data, isLoading, isError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$destinationApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetSingleUserDesQuery"])(id || "");
    const destinations = data?.data?.data;
    const limitedDestinations = destinations?.slice(0, 3);
    if (isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mt-10 container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$DestinationLoader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DestinationLoader"], {}, void 0, false, {
                fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                lineNumber: 34,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
            lineNumber: 33,
            columnNumber: 7
        }, this);
    }
    if (isError) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-center mt-10 text-gray-500",
            children: "Destination is not Available"
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
            lineNumber: 41,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5",
            children: limitedDestinations.map((destination, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-full sm:max-w-[383px] border border-solid border-gray-300 rounded-xl p-[14px]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-[#1D2939] font-semibold text-[16px] sm:text-[18px]",
                                children: [
                                    "Destination #",
                                    index + 1
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                lineNumber: 59,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                            lineNumber: 58,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                            className: "bg-gray-300 mt-3"
                        }, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                            lineNumber: 63,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-sans text-[#344054] font-medium text-[16px] sm:text-[18px] mt-4",
                                    children: [
                                        "My travel type:",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[#475467]",
                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$traveType$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTravelTypeLabel"])(destination.travelType)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                            lineNumber: 67,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                    lineNumber: 65,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "font-sans text-[#344054] font-medium text-[16px] sm:text-[18px] mt-4",
                                    children: [
                                        "My travel begins:",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[#475467] font-normal",
                                            children: new Date(destination?.TravelBegins).toLocaleDateString("en-US", {
                                                month: "long",
                                                year: "numeric",
                                                timeZone: "UTC"
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                            lineNumber: 73,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                    lineNumber: 71,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-sans text-[#344054] font-medium text-[16px] sm:text-[18px] mt-4",
                                    children: [
                                        "Destination country:",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[#475467]",
                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$countryOptions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCountryLabel"])(destination.destinationCountry)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                            lineNumber: 86,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                    lineNumber: 84,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-sans text-[#344054] font-medium text-[16px] sm:text-[18px] mt-4",
                                    children: [
                                        "Destination city:",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-[#475467]",
                                            children: destination.destinationCity || "N/A"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                            lineNumber: 93,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                                    lineNumber: 91,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                            lineNumber: 64,
                            columnNumber: 13
                        }, this)
                    ]
                }, destination.id, true, {
                    fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
                    lineNumber: 54,
                    columnNumber: 11
                }, this))
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
            lineNumber: 52,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfDetialsDest.tsx",
        lineNumber: 48,
        columnNumber: 5
    }, this);
};
_s(ProfDetailsDest, "gglG3e+P9JuBgqYsY/943S49oDM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$destinationApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetSingleUserDesQuery"]
    ];
});
_c = ProfDetailsDest;
var _c;
__turbopack_refresh__.register(_c, "ProfDetailsDest");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/profile/fi_5670747.png [app-client] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/fi_5670747.4d1101bc.png");}}),
"[project]/src/assets/profile/fi_5670747.png.mjs { IMAGE => \"[project]/src/assets/profile/fi_5670747.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5670747$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/profile/fi_5670747.png [app-client] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5670747$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 17,
    height: 17,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA7UlEQVR42jWPTU7DMBCFJ4nj/BU7tHES203T1moiQESUgoALII5QkEgXCCqRBaxYIO7AlRkjdfGkkd7Mm/cBOC7QiFVjafpi0e2tJnr1wsT8wSX039Rj1fYJF51HKCd+kGbTZpvPTl8JDQng5XZ0XFx6fnREaJT4YaL8IM6DmC0c13PBRqbF/FHU5+9ZdbKXZv3J8/pZLjdDzIQG1VwPpbn4Ls3mV5qrj3K5/knzelDN7Zdqbt4AC+2YmN1hPKPhiNMwkbYHptxP1OoJ8FeVTds+5uLMlrTCuct0uwsQABzExCVtyx4wLTKalfX+ALcuHpjcwMqcAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/profile/fi_5796707.png [app-client] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/fi_5796707.b2585a9d.png");}}),
"[project]/src/assets/profile/fi_5796707.png.mjs { IMAGE => \"[project]/src/assets/profile/fi_5796707.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5796707$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/profile/fi_5796707.png [app-client] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5796707$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 17,
    height: 17,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5UlEQVR42jWQPa8BQRiFx80NuW6y9iP2Y8bEsDtiGyLWZ6HS8AsUIqFBiAqJgl5DS+enOq9EMcnknXPO855hv5n/rJFXbUdEc69UW9Kxg3CS/jMES/0wlnNVp1DtvkQlOThcr01PbXA/eeXGHiLJMJyKSmvHo2Rh+1Hf8stDGfeeQicXJM0YRVqeWjkyHmB4h/sahPWxI/SW3j4Cm+tNXtVHXCdXHjVvdhAPgFp9BBQD11lWuw/LLw1NYAhHWMKzTNaQQdjYcyxGCyJtDcMRhpfpFjsshSoQCar2rQn+3HJVO40veAPSQyx948UzFgAAAABJRU5ErkJggg==",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/userProfile/ProfileViewLoder.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "ProfileViewLoder": (()=>ProfileViewLoder)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const ProfileViewLoder = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col md:flex-row items-start justify-between p-4 md:p-6 gap-4 bg-white animate-pulse",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col md:flex-row gap-8 items-center w-full md:w-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative w-32 h-32 md:w-[133px] md:h-[133px] bg-gray-300 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                            lineNumber: 8,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center md:text-left",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-6 bg-gray-300 rounded w-3/4 my-2"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                    lineNumber: 10,
                                    columnNumber: 7
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col sm:flex-row gap-4 mt-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "block text-lg md:text-[18px] font-semibold font-sans h-6 bg-gray-300 rounded w-3/4 my-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                                    lineNumber: 13,
                                                    columnNumber: 11
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex justify-center gap-4 mt-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-2 w-1/2 h-6 bg-gray-300 rounded my-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                                            lineNumber: 15,
                                                            columnNumber: 13
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-2 w-1/2 h-6 bg-gray-300 rounded my-2"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                                            lineNumber: 16,
                                                            columnNumber: 13
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                                    lineNumber: 14,
                                                    columnNumber: 11
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                            lineNumber: 12,
                                            columnNumber: 9
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm flex flex-col justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-lg md:text-[18px] font-semibold font-sans h-6 bg-gray-300 rounded w-3/4 my-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                                    lineNumber: 20,
                                                    columnNumber: 11
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-lg md:text-[18px] font-semibold font-sans h-6 bg-gray-300 rounded w-3/4 my-2"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                                    lineNumber: 21,
                                                    columnNumber: 11
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                            lineNumber: 19,
                                            columnNumber: 9
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                                    lineNumber: 11,
                                    columnNumber: 7
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                            lineNumber: 9,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                    lineNumber: 7,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center gap-6 md:gap-[84px] w-full md:w-auto",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 px-4 py-2 md:px-3 md:py-1 bg-gray-300 rounded-xl text-[#000] text-sm md:text-base font-normal font-sans h-10 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                            lineNumber: 27,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-primary underline text-lg md:text-xl font-semibold h-6 bg-gray-300 rounded w-1/2 my-2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                            lineNumber: 28,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
                    lineNumber: 26,
                    columnNumber: 3
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
            lineNumber: 6,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/userProfile/ProfileViewLoder.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
};
_c = ProfileViewLoder;
var _c;
__turbopack_refresh__.register(_c, "ProfileViewLoder");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/redux/Api/favariteApi.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "useGetMyfavQuery": (()=>useGetMyfavQuery),
    "useMyfavAddMutation": (()=>useMyfavAddMutation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/baseApi.ts [app-client] (ecmascript)");
;
const favariteApi = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].injectEndpoints({
    endpoints: (build)=>({
            myfavAdd: build.mutation({
                query: (data)=>({
                        url: "/favorites/toggle",
                        method: "POST",
                        body: data
                    }),
                invalidatesTags: [
                    "favourite",
                    "AllDestination",
                    "Destination",
                    "Lifestyle"
                ]
            }),
            getMyfav: build.query({
                query: ()=>({
                        url: "favorites",
                        method: "GET"
                    }),
                providesTags: [
                    "favourite",
                    "AllDestination",
                    "User"
                ]
            })
        })
});
const { useMyfavAddMutation, useGetMyfavQuery } = favariteApi;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/stateOptions.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "getStateLabel": (()=>getStateLabel),
    "stateOptions": (()=>stateOptions)
});
const stateOptions = [
    {
        value: "al",
        label: "Alabama (AL)"
    },
    {
        value: "ak",
        label: "Alaska (AK)"
    },
    {
        value: "ab",
        label: "Alberta (CAN)"
    },
    {
        value: "az",
        label: "Arizona (AZ)"
    },
    {
        value: "ar",
        label: "Arkansas (AR)"
    },
    {
        value: "bc",
        label: "British Columbia (CAN)"
    },
    {
        value: "ca",
        label: "California (CA)"
    },
    {
        value: "co",
        label: "Colorado (CO)"
    },
    {
        value: "ct",
        label: "Connecticut (CT)"
    },
    {
        value: "de",
        label: "Delaware (DE)"
    },
    {
        value: "dc",
        label: "District of Columbia (DC)"
    },
    {
        value: "fl",
        label: "Florida (FL)"
    },
    {
        value: "ga",
        label: "Georgia (GA)"
    },
    {
        value: "hi",
        label: "Hawaii (HI)"
    },
    {
        value: "id",
        label: "Idaho (ID)"
    },
    {
        value: "il",
        label: "Illinois (IL)"
    },
    {
        value: "in",
        label: "Indiana (IN)"
    },
    {
        value: "ia",
        label: "Iowa (IA)"
    },
    {
        value: "ks",
        label: "Kansas (KS)"
    },
    {
        value: "ky",
        label: "Kentucky (KY)"
    },
    {
        value: "lb",
        label: "Labrador (CAN)"
    },
    {
        value: "la",
        label: "Louisiana (LA)"
    },
    {
        value: "me",
        label: "Maine (ME)"
    },
    {
        value: "mb",
        label: "Manitoba (CAN)"
    },
    {
        value: "md",
        label: "Maryland (MD)"
    },
    {
        value: "ma",
        label: "Massachusetts (MA)"
    },
    {
        value: "mi",
        label: "Michigan (MI)"
    },
    {
        value: "mn",
        label: "Minnesota (MN)"
    },
    {
        value: "ms",
        label: "Mississippi (MS)"
    },
    {
        value: "mo",
        label: "Missouri (MO)"
    },
    {
        value: "mt",
        label: "Montana (MT)"
    },
    {
        value: "ne",
        label: "Nebraska (NE)"
    },
    {
        value: "nv",
        label: "Nevada (NV)"
    },
    {
        value: "nb",
        label: "New Brunswick (CAN)"
    },
    {
        value: "nh",
        label: "New Hampshire (NH)"
    },
    {
        value: "nj",
        label: "New Jersey (NJ)"
    },
    {
        value: "nm",
        label: "New Mexico (NM)"
    },
    {
        value: "ny",
        label: "New York (NY)"
    },
    {
        value: "nl",
        label: "Newfoundland (CAN)"
    },
    {
        value: "nc",
        label: "North Carolina (NC)"
    },
    {
        value: "nd",
        label: "North Dakota (ND)"
    },
    {
        value: "nt",
        label: "Northwest Territories (CAN)"
    },
    {
        value: "ns",
        label: "Nova Scotia (CAN)"
    },
    {
        value: "nu",
        label: "Nunavut (CAN)"
    },
    {
        value: "oh",
        label: "Ohio (OH)"
    },
    {
        value: "ok",
        label: "Oklahoma (OK)"
    },
    {
        value: "on",
        label: "Ontario (CAN)"
    },
    {
        value: "or",
        label: "Oregon (OR)"
    },
    {
        value: "pa",
        label: "Pennsylvania (PA)"
    },
    {
        value: "pe",
        label: "Prince Edward Island (CAN)"
    },
    {
        value: "qc",
        label: "Quebec (CAN)"
    },
    {
        value: "ri",
        label: "Rhode Island (RI)"
    },
    {
        value: "sk",
        label: "Saskatchewan (CAN)"
    },
    {
        value: "sc",
        label: "South Carolina (SC)"
    },
    {
        value: "sd",
        label: "South Dakota (SD)"
    },
    {
        value: "tn",
        label: "Tennessee (TN)"
    },
    {
        value: "tx",
        label: "Texas (TX)"
    },
    {
        value: "ut",
        label: "Utah (UT)"
    },
    {
        value: "vt",
        label: "Vermont (VT)"
    },
    {
        value: "va",
        label: "Virginia (VA)"
    },
    {
        value: "wa",
        label: "Washington (WA)"
    },
    {
        value: "wv",
        label: "West Virginia (WV)"
    },
    {
        value: "wi",
        label: "Wisconsin (WI)"
    },
    {
        value: "wy",
        label: "Wyoming (WY)"
    },
    {
        value: "yt",
        label: "Yukon (CAN)"
    }
];
const getStateLabel = (stateValue)=>{
    const state = stateOptions.find((option)=>option.value == stateValue);
    return state?.label ? state.label : "N/A";
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "Dialog": (()=>Dialog),
    "DialogClose": (()=>DialogClose),
    "DialogContent": (()=>DialogContent),
    "DialogDescription": (()=>DialogDescription),
    "DialogFooter": (()=>DialogFooter),
    "DialogHeader": (()=>DialogHeader),
    "DialogOverlay": (()=>DialogOverlay),
    "DialogPortal": (()=>DialogPortal),
    "DialogTitle": (()=>DialogTitle),
    "DialogTrigger": (()=>DialogTrigger)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-dialog/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
const Dialog = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root;
const DialogTrigger = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Trigger;
const DialogPortal = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Portal;
const DialogClose = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Close;
const DialogOverlay = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Overlay, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("fixed inset-0    data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 21,
        columnNumber: 3
    }, this));
_c = DialogOverlay;
DialogOverlay.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Overlay.displayName;
const DialogContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c1 = ({ className, children, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogPortal, {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogOverlay, {}, void 0, false, {
                fileName: "[project]/src/components/ui/dialog.tsx",
                lineNumber: 37,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content, {
                ref: ref,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border border-neutral-200 bg-white p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg dark:border-neutral-800 dark:bg-neutral-950", className),
                ...props,
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/ui/dialog.tsx",
                lineNumber: 38,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, this));
_c2 = DialogContent;
DialogContent.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content.displayName;
const DialogHeader = ({ className, ...props })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 text-center sm:text-left", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 60,
        columnNumber: 3
    }, this);
_c3 = DialogHeader;
DialogHeader.displayName = "DialogHeader";
const DialogFooter = ({ className, ...props })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 74,
        columnNumber: 3
    }, this);
_c4 = DialogFooter;
DialogFooter.displayName = "DialogFooter";
const DialogTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c5 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Title, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-lg font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 88,
        columnNumber: 3
    }, this));
_c6 = DialogTitle;
DialogTitle.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Title.displayName;
const DialogDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.forwardRef(_c7 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Description, {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-neutral-500 dark:text-neutral-400", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/dialog.tsx",
        lineNumber: 103,
        columnNumber: 3
    }, this));
_c8 = DialogDescription;
DialogDescription.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Description.displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
__turbopack_refresh__.register(_c, "DialogOverlay");
__turbopack_refresh__.register(_c1, "DialogContent$React.forwardRef");
__turbopack_refresh__.register(_c2, "DialogContent");
__turbopack_refresh__.register(_c3, "DialogHeader");
__turbopack_refresh__.register(_c4, "DialogFooter");
__turbopack_refresh__.register(_c5, "DialogTitle$React.forwardRef");
__turbopack_refresh__.register(_c6, "DialogTitle");
__turbopack_refresh__.register(_c7, "DialogDescription$React.forwardRef");
__turbopack_refresh__.register(_c8, "DialogDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/chatModal/chat.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ChatModal)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/messagesApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/userApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-dialog/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
;
var _s = __turbopack_refresh__.signature();
;
;
;
;
;
;
function ChatModal({ isOpen, setOpen, floatingButtonIsDisplayed, setFloatingButtonDisplay, profileId }) {
    _s();
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [conversation, setConversation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // const [messages, sendMessage] = useState<MessageProps[]>([]);
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { data: userData, isLoading, isError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetUserQuery"])(undefined);
    const { data: conversations, error, isLoading: isConversationsLoading, refetch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetAllConversationsQuery"])(undefined);
    const [createConversation, { isLoading: createConversationLoading, isError: createConversationError }] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCreateConversationMutation"])();
    const [sendMessage, { isLoading: sendMessageLoading, isError: sendMessageError }] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSendMessageMutation"])();
    const shouldPoll = isOpen && !!conversation?.id;
    const { data: messagesData, isLoading: messagesLoading, isError: messagesError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetMessageByConvoQuery"])(conversation?.id, {
        skip: !conversation?.id,
        pollingInterval: shouldPoll ? 10000 : 0
    });
    const participants = [
        profileId,
        userData?.data?.id
    ];
    // useEffect(() => {
    //   if (!conversations?.data) return;
    //   const currentConv = conversations.data.filter((conv: any) =>
    //     participants.every((part) => conv.participants.includes(part))
    //   );
    //   if (currentConv?.length > 0) {
    //     setConversation(currentConv[0]);
    //     currentConv[0].messages;
    //   } else {
    //     createCurrentConversation();
    //   }
    // }, [conversations]);
    // const createCurrentConversation = async () => {
    //   try {
    //     await createConversation(participants).unwrap();
    //     refetch();
    //   } catch (error) {
    //     console.error("Failed to create conversation:", error);
    //   }
    // };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatModal.useEffect": ()=>{
            if (!conversations?.data) return;
            const currentConv = conversations.data.filter({
                "ChatModal.useEffect.currentConv": (conv)=>participants.every({
                        "ChatModal.useEffect.currentConv": (part)=>conv.participants.includes(part)
                    }["ChatModal.useEffect.currentConv"])
            }["ChatModal.useEffect.currentConv"]);
            if (currentConv.length > 0) {
                setConversation(currentConv[0]);
            } else {
                createCurrentConversation();
            }
        }
    }["ChatModal.useEffect"], [
        conversations
    ]);
    const createCurrentConversation = async ()=>{
        try {
            const response = await createConversation(participants).unwrap();
            refetch(); // Refresh conversations
        } catch (error) {
        // console.log(error);
        // console.error(
        //   "❌ Failed to create conversation:",
        //   error?.data || error?.message || error
        // );
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatModal.useEffect": ()=>{
            messagesEndRef.current?.scrollIntoView({
                behavior: "smooth"
            });
        }
    }["ChatModal.useEffect"], [
        conversation?.messages
    ]);
    const handleSend = async ()=>{
        if (!input.trim()) return;
        const newMessage = {
            id: Date.now().toString(),
            conversationId: conversation?.id,
            text: input,
            senderId: userData?.data?.id || "Unknown",
            createdAt: new Date().toISOString()
        };
        try {
            await sendMessage({
                conversationId: conversation.id,
                text: input
            });
        } catch (error) {
            console.error("Error sending message:", error);
        }
        setInput("");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            floatingButtonIsDisplayed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>{
                    setOpen(true);
                    setFloatingButtonDisplay(false);
                },
                className: "fixed bottom-5 right-5 bg-primary text-white p-3 rounded-full shadow-lg",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                    className: "w-6 h-6"
                }, void 0, false, {
                    fileName: "[project]/src/components/chatModal/chat.tsx",
                    lineNumber: 170,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/chatModal/chat.tsx",
                lineNumber: 163,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
                open: isOpen,
                onOpenChange: (state)=>{
                    setOpen(state);
                    setFloatingButtonDisplay(!state);
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
                    "aria-describedby": undefined,
                    className: "max-w-md p-4 bg-white rounded-lg shadow-lg z-[9991]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {}, void 0, false, {
                                fileName: "[project]/src/components/chatModal/chat.tsx",
                                lineNumber: 187,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/chatModal/chat.tsx",
                            lineNumber: 186,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-bold",
                                    children: "Chat"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/chatModal/chat.tsx",
                                    lineNumber: 190,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-[12px] text-center",
                                    children: [
                                        "You can send Zoom or Google Meet",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/src/components/chatModal/chat.tsx",
                                            lineNumber: 193,
                                            columnNumber: 15
                                        }, this),
                                        " invites through the message system"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/chatModal/chat.tsx",
                                    lineNumber: 191,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        setOpen(false);
                                        setFloatingButtonDisplay(true);
                                    },
                                    className: "p-1 rounded-full bg-gray-200",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/chatModal/chat.tsx",
                                        lineNumber: 203,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/chatModal/chat.tsx",
                                    lineNumber: 196,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/chatModal/chat.tsx",
                            lineNumber: 189,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-80 overflow-y-auto p-4",
                            children: [
                                messagesData?.data?.map((msg)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `p-2 my-2 rounded-lg max-w-[75%] ${msg.senderId === userData?.data?.id ? "bg-blue-500 text-white self-end ml-auto" : "bg-gray-300 text-black"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "block leading-4 break-words",
                                                children: msg.text
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/chatModal/chat.tsx",
                                                lineNumber: 217,
                                                columnNumber: 17
                                            }, this),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "block ms-auto max-w-max text-[10px]",
                                                children: new Date(msg.createdAt).toLocaleTimeString()
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/chatModal/chat.tsx",
                                                lineNumber: 218,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, msg.id, true, {
                                        fileName: "[project]/src/components/chatModal/chat.tsx",
                                        lineNumber: 209,
                                        columnNumber: 15
                                    }, this)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    ref: messagesEndRef
                                }, void 0, false, {
                                    fileName: "[project]/src/components/chatModal/chat.tsx",
                                    lineNumber: 223,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/chatModal/chat.tsx",
                            lineNumber: 207,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-2 border-t flex",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    className: "flex-1 p-2 border rounded-lg",
                                    placeholder: "Type a message...",
                                    value: input,
                                    onChange: (e)=>setInput(e.target.value),
                                    onKeyDown: (e)=>e.key === "Enter" && handleSend()
                                }, void 0, false, {
                                    fileName: "[project]/src/components/chatModal/chat.tsx",
                                    lineNumber: 228,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleSend,
                                    className: "ml-2 px-4 py-2 bg-primary text-white rounded-lg",
                                    children: "Send"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/chatModal/chat.tsx",
                                    lineNumber: 236,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/chatModal/chat.tsx",
                            lineNumber: 227,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/chatModal/chat.tsx",
                    lineNumber: 182,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/chatModal/chat.tsx",
                lineNumber: 175,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ChatModal, "eNQkyJ1zXX/yJ95KhcTdJLE2dM8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetUserQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetAllConversationsQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCreateConversationMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSendMessageMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$messagesApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetMessageByConvoQuery"]
    ];
});
_c = ChatModal;
var _c;
__turbopack_refresh__.register(_c, "ChatModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/profile/gender.svg [app-client] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/gender.2e1df43d.svg");}}),
"[project]/src/assets/profile/gender.svg.mjs { IMAGE => \"[project]/src/assets/profile/gender.svg [app-client] (static)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$gender$2e$svg__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/profile/gender.svg [app-client] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$gender$2e$svg__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 100,
    height: 100,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/profile/seeking.svg [app-client] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/seeking.6cfab34a.svg");}}),
"[project]/src/assets/profile/seeking.svg.mjs { IMAGE => \"[project]/src/assets/profile/seeking.svg [app-client] (static)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$seeking$2e$svg__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/profile/seeking.svg [app-client] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$seeking$2e$svg__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 100,
    height: 100,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/assets/placholder.png [app-client] (static)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
__turbopack_export_value__("/_next/static/media/placholder.4713bc78.png");}}),
"[project]/src/assets/placholder.png.mjs { IMAGE => \"[project]/src/assets/placholder.png [app-client] (static)\" } [app-client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$placholder$2e$png__$5b$app$2d$client$5d$__$28$static$29$__ = __turbopack_import__("[project]/src/assets/placholder.png [app-client] (static)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$placholder$2e$png__$5b$app$2d$client$5d$__$28$static$29$__["default"],
    width: 204,
    height: 192,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAR0lEQVR42o2NOwrAQAhE9/5HsvYsimAKGz9VIukkhN1XDMO8Ytb9w9qIzIyIzqoaQkRUlZnNbIieEBEAiGgId79eupydf3kAR5K7S3O0EcYAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/profileDetails/ProfileDetailsView.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "ProfileDetailsView": (()=>ProfileDetailsView)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/ui/avatar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5670747$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5670747$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/profile/fi_5670747.png.mjs { IMAGE => "[project]/src/assets/profile/fi_5670747.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5796707$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5796707$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/profile/fi_5796707.png.mjs { IMAGE => "[project]/src/assets/profile/fi_5796707.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/userApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$ProfileViewLoder$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/userProfile/ProfileViewLoder.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/sonner/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$favariteApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/favariteApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$countryOptions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/constants/countryOptions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$stateOptions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/constants/stateOptions.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$chatModal$2f$chat$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/chatModal/chat.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$gender$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$profile$2f$gender$2e$svg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/profile/gender.svg.mjs { IMAGE => "[project]/src/assets/profile/gender.svg [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$seeking$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$profile$2f$seeking$2e$svg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/profile/seeking.svg.mjs { IMAGE => "[project]/src/assets/profile/seeking.svg [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$placholder$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$placholder$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_import__('[project]/src/assets/placholder.png.mjs { IMAGE => "[project]/src/assets/placholder.png [app-client] (static)" } [app-client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$antd$2f$es$2f$image$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__ = __turbopack_import__("[project]/node_modules/antd/es/image/index.js [app-client] (ecmascript) <export default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__ = __turbopack_import__("[project]/node_modules/lucide-react/dist/esm/icons/heart.js [app-client] (ecmascript) <export default as Heart>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/react-icons/fa/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ProfileDetailsView = ()=>{
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])(); // Profile ID from URL params
    const charLimit = 300;
    const [currentUserData, setCurrentUserData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const [isFavorite, setIsFavorite] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // Manage favorite state
    const [chatModalisOpen, setChatModalIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [userBio, setUserBio] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [editBio, setEditBio] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [updateUserBio] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateUserBioMutation"])();
    const [floatingButtonIsDisplayed, setFloatingButtonIsDisplayed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [addFavorite, { data: res, isLoading: addProfile }] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$favariteApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMyfavAddMutation"])();
    const { data: profiles, isLoading: favLoading, isError: favError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$favariteApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetMyfavQuery"])(undefined); // Get all favorite profiles
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfileDetailsView.useEffect": ()=>{
            // Check if current profile id is in the favorites list
            if (profiles?.data) {
                const isAlreadyFavorited = profiles.data.some({
                    "ProfileDetailsView.useEffect.isAlreadyFavorited": (profile)=>profile.userId === id
                }["ProfileDetailsView.useEffect.isAlreadyFavorited"]);
                setIsFavorite(isAlreadyFavorited);
            }
        }
    }["ProfileDetailsView.useEffect"], [
        profiles,
        id
    ]);
    const handleToggleFavorite = async (id)=>{
        const toastID = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].loading(isFavorite ? "Removing from Saved profile" : "Adding to Saved Profile");
        try {
            // Call the API to add/remove favorite
            const response = await addFavorite({
                userId: id
            }).unwrap();
            // Toggle the favorite status
            setIsFavorite(!isFavorite);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success(isFavorite ? "Removed from Saved Profile!" : "Added to Saved Profile!", {
                id: toastID
            });
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(error.message, {
                id: toastID
            });
        }
    };
    const { data, isLoading, isError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetUserByIdQuery"])(id);
    const { data: userData, isLoading: userLoading, isError: userError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetUserQuery"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfileDetailsView.useEffect": ()=>{
            setCurrentUserData(userData?.data);
        }
    }["ProfileDetailsView.useEffect"], [
        userData
    ]);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [avatarSrc, setAvatarSrc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("profile.png");
    const handleImageUpload = (event)=>{
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e)=>{
                setAvatarSrc(e.target?.result);
            };
            reader.readAsDataURL(file);
        }
    };
    const triggerFileInput = ()=>{
        fileInputRef.current?.click();
    };
    if (!id) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center mt-10 text-red-500",
            children: "No Profiles ID provided."
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
            lineNumber: 134,
            columnNumber: 7
        }, this);
    }
    if (isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$ProfileViewLoder$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileViewLoder"], {}, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
            lineNumber: 141,
            columnNumber: 12
        }, this);
    }
    if (isError) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: "Error loading user data."
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
            lineNumber: 145,
            columnNumber: 12
        }, this);
    }
    const currentUser = data?.data;
    // console.log("My Profile Detail", currentUser);
    const date = new Date(currentUser?.createdAt);
    const joinedDate = date.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    });
    if (!userData) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: "Loading..."
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
            lineNumber: 160,
            columnNumber: 12
        }, this);
    }
    // Update Bio
    const handleUpdateBio = async ()=>{
        try {
            // Show a loading indicator
            const loadingToastId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].loading("Updating bio...");
            // Call the API to change the password
            const response = await updateUserBio({
                userBio
            }).unwrap();
            // Check the API response (if additional checks are needed)
            if (response?.success) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success("Bio update successfully!");
                setEditBio(false);
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(response?.message || "Failed to update the bio.");
            }
            // Dismiss the loading toast
            if (!isLoading) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].dismiss(loadingToastId);
            }
        } catch (error) {
            // Handle errors and show the appropriate message
            if (error?.data?.message) {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(error.data.message);
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error("An unexpected error occurred. Please try again.");
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col md:flex-row items-start justify-between p-4 md:p-6 gap-4 bg-white",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col md:flex-row gap-8 items-center w-full md:w-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-36 h-36 rounded-full overflow-hidden flex items-center justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$avatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Avatar"], {
                                    className: "w-[133px] h-[133px]  border-2 border-slate-200",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$antd$2f$es$2f$image$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"], {
                                        src: currentUser.profileImage || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$placholder$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$placholder$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                        alt: "Profile Image",
                                        width: 130,
                                        height: 130,
                                        className: "object-cover w-full h-full"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                        lineNumber: 201,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                    lineNumber: 200,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                lineNumber: 199,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center md:text-left",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-start items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                className: "text-xl md:text-2xl lg:text-[32px] text-[#263238] font-bold me-5",
                                                children: [
                                                    currentUser?.firstName,
                                                    " ",
                                                    currentUser?.lastName || "N/A"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 222,
                                                columnNumber: 15
                                            }, this),
                                            data?.data?.summitVerify && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "inline-flex items-center justify-center w-5 h-5 rounded-full bg-blue-500",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    className: "w-3 h-3 text-white",
                                                    viewBox: "0 0 24 24",
                                                    fill: "currentColor",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        d: "M9 16.2l-3.5-3.6L4 14.2 9 19l12-12-1.4-1.4z"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                        lineNumber: 233,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                    lineNumber: 227,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 226,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                        lineNumber: 221,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-lg md:text-[13px] font-semibold mt-1",
                                        children: [
                                            "Date Joined:",
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-base md:text-[16px] font-medium",
                                                children: joinedDate
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 241,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                        lineNumber: 239,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex flex-col gap-6 mt-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col sm:flex-row justify-between gap-5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-lg md:text-[18px] font-semibold",
                                                        children: [
                                                            "Current Country:",
                                                            " ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-base md:text-[16px] font-medium",
                                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$countryOptions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCountryLabel"])(currentUser?.country)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                lineNumber: 252,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                        lineNumber: 250,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-lg md:text-[18px] font-semibold",
                                                        children: [
                                                            "Current City:",
                                                            " ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-base md:text-[16px] font-medium",
                                                                children: currentUser?.city || "N/A"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                lineNumber: 258,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                        lineNumber: 256,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 249,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-lg md:text-[18px] font-semibold",
                                                    children: [
                                                        "Current State/Province:",
                                                        " ",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-base md:text-[16px] font-medium",
                                                            children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$stateOptions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStateLabel"])(currentUser?.state)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                            lineNumber: 268,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                    lineNumber: 266,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 265,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex flex-col sm:flex-row  gap-[3.3rem]",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-10",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5796707$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5796707$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                                    alt: "Zodiac Icon"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                    lineNumber: 278,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-[#1D2939] text-sm md:text-base font-semibold",
                                                                    children: currentUser?.zodiac || "N/A"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                    lineNumber: 279,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                            lineNumber: 277,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5670747$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$profile$2f$fi_5670747$2e$png__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                                    alt: "Age Icon"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                    lineNumber: 284,
                                                                    columnNumber: 21
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-[#1D2939] text-sm md:text-base font-semibold",
                                                                    children: [
                                                                        currentUser?.age || "N/A",
                                                                        " y"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                    lineNumber: 285,
                                                                    columnNumber: 21
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                            lineNumber: 283,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                    lineNumber: 276,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 275,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex gap-10",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-3",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$gender$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$profile$2f$gender$2e$svg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                                alt: "Zodiac Icon",
                                                                width: 20,
                                                                height: 20
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                lineNumber: 301,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-[#1D2939] text-sm md:text-base font-semibold",
                                                                children: [
                                                                    "Gender:",
                                                                    " ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-base md:text-[16px] font-medium",
                                                                        children: userData?.data?.gender
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                        lineNumber: 309,
                                                                        columnNumber: 21
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                lineNumber: 307,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                        lineNumber: 300,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-3",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$assets$2f$profile$2f$seeking$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$src$2f$assets$2f$profile$2f$seeking$2e$svg__$5b$app$2d$client$5d$__$28$static$2922$__$7d$__$5b$app$2d$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                                alt: "Age Icon",
                                                                width: 20,
                                                                height: 20
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                lineNumber: 315,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-[#1D2939] text-sm md:text-base font-semibold",
                                                                children: [
                                                                    "Seeking:",
                                                                    " ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-base md:text-[16px] font-medium",
                                                                        children: userData?.data?.memberSeeking
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                        lineNumber: 323,
                                                                        columnNumber: 21
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                                lineNumber: 321,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                        lineNumber: 314,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 299,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                        lineNumber: 247,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-center gap-6 md:gap-[84px] w-full md:w-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleToggleFavorite(id),
                                className: "flex items-center gap-2 px-4 py-2 md:px-3 md:py-1 bg-[#CECECE] rounded-xl text-[#000] text-sm md:text-base font-normal font-sans",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$heart$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Heart$3e$__["Heart"], {
                                        className: `w-4 h-4 stroke-none fill-red-500  }`
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                        lineNumber: 338,
                                        columnNumber: 13
                                    }, this),
                                    isFavorite ? "Saved Profile" : "Save profile"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                lineNumber: 334,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: `rounded-xl  px-[20px] h-[30px] ${!currentUserData?.summitVerify ? "bg-gray-600 text-white" : "bg-primary text-white"}`,
                                        onClick: ()=>setChatModalIsOpen(true),
                                        disabled: !currentUserData?.summitVerify,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                className: "fa-solid fa-comment me-2"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 351,
                                                columnNumber: 15
                                            }, this),
                                            "Chat"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                        lineNumber: 342,
                                        columnNumber: 13
                                    }, this),
                                    !currentUserData?.summitVerify && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-center items-center px-[10px] py-[2px] bg-gray-400 rounded-lg mt-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaExclamationCircle"], {
                                                className: "me-2",
                                                color: "#fff"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 355,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-white select-none",
                                                children: "You have to get verified to chat!"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                                lineNumber: 356,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                        lineNumber: 354,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                                lineNumber: 341,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                        lineNumber: 333,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                lineNumber: 197,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg md:text-xl font-sans font-bold mt-10 md:mt-[65px]",
                        children: "About Me – Bio"
                    }, void 0, false, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                        lineNumber: 367,
                        columnNumber: 9
                    }, this),
                    !editBio ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-base md:text-[18px] font-normal font-sans mt-5 text-[#475467]",
                        children: userBio
                    }, void 0, false, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                        lineNumber: 372,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        value: userBio,
                        onChange: (e)=>{
                            if (e.target.value.length <= charLimit) {
                                setUserBio(e.target.value);
                            }
                        },
                        placeholder: "Type here...",
                        rows: 5,
                        className: "w-full p-2 text-base border-none focus:outline-none"
                    }, void 0, false, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                        lineNumber: 376,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "mt-7 bg-primary flex items-center justify-center md:justify-start px-4 md:px-6 py-2 md:py-3 gap-2 md:gap-3 rounded-xl text-white",
                        onClick: ()=>editBio ? handleUpdateBio() : setEditBio(true),
                        children: editBio ? "Update" : "Edit Bio"
                    }, void 0, false, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                        lineNumber: 389,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                lineNumber: 366,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$chatModal$2f$chat$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: chatModalisOpen,
                setOpen: setChatModalIsOpen,
                floatingButtonIsDisplayed: floatingButtonIsDisplayed,
                setFloatingButtonDisplay: setFloatingButtonIsDisplayed,
                profileId: id
            }, void 0, false, {
                fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
                lineNumber: 396,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/profileDetails/ProfileDetailsView.tsx",
        lineNumber: 196,
        columnNumber: 5
    }, this);
};
_s(ProfileDetailsView, "UGwxeDvJJbttaHBQQpgDjxuU0OQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateUserBioMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$favariteApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMyfavAddMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$favariteApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetMyfavQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetUserByIdQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$userApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetUserQuery"]
    ];
});
_c = ProfileDetailsView;
var _c;
__turbopack_refresh__.register(_c, "ProfileDetailsView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/redux/Api/lifeCicleApi.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "useGetLifestyleUserQuery": (()=>useGetLifestyleUserQuery),
    "useLifStyleMyQuery": (()=>useLifStyleMyQuery),
    "useLifeCicleAddMutation": (()=>useLifeCicleAddMutation),
    "useUpdateLifeStyleMutation": (()=>useUpdateLifeStyleMutation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/baseApi.ts [app-client] (ecmascript)");
;
const userApi = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].injectEndpoints({
    endpoints: (build)=>({
            lifeCicleAdd: build.mutation({
                query: (data)=>{
                    return {
                        url: "/lifestyle/create",
                        method: "POST",
                        body: data
                    };
                },
                invalidatesTags: [
                    "Lifestyle"
                ]
            }),
            lifStyleMy: build.query({
                query: ()=>{
                    return {
                        url: "/lifestyle/my-lifestyle",
                        method: "GET"
                    };
                },
                providesTags: [
                    "Lifestyle"
                ]
            }),
            getLifestyleUser: build.query({
                query: (id)=>({
                        url: `lifestyle/user/${id}`,
                        method: "GET"
                    }),
                providesTags: [
                    "Lifestyle"
                ]
            }),
            updateLifeStyle: build.mutation({
                query: (data)=>({
                        url: `/lifestyle`,
                        method: "PUT",
                        body: data
                    }),
                invalidatesTags: [
                    "Lifestyle"
                ]
            })
        })
});
const { useLifeCicleAddMutation, useLifStyleMyQuery, useGetLifestyleUserQuery, useUpdateLifeStyleMutation } = userApi;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/userProfile/LifeStyleViwLoder.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "LifeStyleViwLoder": (()=>LifeStyleViwLoder)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const LifeStyleViwLoder = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 gap-y-6 animate-pulse",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-span-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 mb-1 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 8,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 w-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 9,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                    lineNumber: 7,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-span-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 mb-1 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 12,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 w-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 13,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                    lineNumber: 11,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-span-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 mb-1 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 16,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 w-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 17,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                    lineNumber: 15,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-span-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 mb-1 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 20,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 w-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 21,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                    lineNumber: 19,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-span-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 mb-1 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 24,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 w-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 25,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                    lineNumber: 23,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-span-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 mb-1 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 28,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 w-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 29,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                    lineNumber: 27,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-span-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 mb-1 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 32,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 w-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 33,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                    lineNumber: 31,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-span-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 mb-1 w-1/2"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 36,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-4 bg-gray-300 w-full"
                        }, void 0, false, {
                            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                            lineNumber: 37,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
                    lineNumber: 35,
                    columnNumber: 3
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
            lineNumber: 6,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/userProfile/LifeStyleViwLoder.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
};
_c = LifeStyleViwLoder;
var _c;
__turbopack_refresh__.register(_c, "LifeStyleViwLoder");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/constants/industry.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "getIndustryLabel": (()=>getIndustryLabel),
    "industryOptions": (()=>industryOptions)
});
const industryOptions = [
    {
        label: "Accounting & Finance",
        value: "acc"
    },
    {
        label: "Animal/Pet & Veterinarian Services",
        value: "apv"
    },
    {
        label: "Beauty, Cosmetics & Salon Services",
        value: "bcs"
    },
    {
        label: "Business Consulting & Coaching",
        value: "bcc"
    },
    {
        label: "Childcare",
        value: "chl"
    },
    {
        label: "Construction & Trades",
        value: "ctd"
    },
    {
        label: "Creative & Media",
        value: "cmd"
    },
    {
        label: "Counseling & Therapy",
        value: "cnt"
    },
    {
        label: "Education & Tutoring",
        value: "edu"
    },
    {
        label: "Environmental & Agricultural Services",
        value: "eas"
    },
    {
        label: "Fine Arts, Artisan & Craft Work",
        value: "fac"
    },
    {
        label: "Health & Wellness",
        value: "hw"
    },
    {
        label: "Hospitality & Food Services",
        value: "hfs"
    },
    {
        label: "Legal & Consulting Services",
        value: "lcs"
    },
    {
        label: "Media & Journalism",
        value: "mj"
    },
    {
        label: "Office Administration",
        value: "oa"
    },
    {
        label: "Photography & Video Services",
        value: "pvs"
    },
    {
        label: "Real Estate",
        value: "re"
    },
    {
        label: "Recruiting & Staffing",
        value: "rs"
    },
    {
        label: "Retail & E-Commerce",
        value: "rec"
    },
    {
        label: "Sales & Marketing",
        value: "sm"
    },
    {
        label: "Technology & IT",
        value: "ti"
    },
    {
        label: "Transportation & Logistics",
        value: "tl"
    },
    {
        label: "Travel, Hospitality & Tourism",
        value: "tht"
    }
];
const getIndustryLabel = (industryValue)=>{
    const industry = industryOptions.find((option)=>option.value === industryValue);
    return industry?.label ? industry.label : "N/A";
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/profileDetails/ProfLifeStyleView.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "ProfLifeStyleView": (()=>ProfLifeStyleView)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$lifeCicleApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/lifeCicleApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$LifeStyleViwLoder$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/userProfile/LifeStyleViwLoder.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$industry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/constants/industry.ts [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
;
;
;
;
;
const ProfLifeStyleView = ()=>{
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const { data, isLoading, isError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$lifeCicleApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetLifestyleUserQuery"])(id);
    const membership = data?.data?.user?.planName;
    const lifestyleUser = data?.data;
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container my-16",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$LifeStyleViwLoder$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LifeStyleViwLoder"], {}, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
            lineNumber: 43,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
        lineNumber: 42,
        columnNumber: 7
    }, this);
    if (isError) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: " my-16",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "font-sans text-xl sm:text-2xl md:text-3xl font-bold text-[#1D2939] text-center md:text-left pb-5",
            children: "LifeStyle"
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
            lineNumber: 49,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
        lineNumber: 48,
        columnNumber: 7
    }, this);
    if (isError) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto my-44 text-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-red-500",
                children: "no lifestyle available."
            }, void 0, false, {
                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                lineNumber: 59,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
            lineNumber: 58,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
        lineNumber: 57,
        columnNumber: 7
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "mt-16",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4 gap-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                    children: "Max Monthly Rent"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 72,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                    children: [
                                        "$",
                                        lifestyleUser?.monthlyBudget || "N/A"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 75,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                    children: "Marital Status"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 80,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                    children: lifestyleUser?.maritalStatus || "N/A"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 83,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                            lineNumber: 79,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                    children: "Ethnicity"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 88,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                    children: lifestyleUser?.ethnicity || "N/A"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 91,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                    children: "Religion/Spirituality"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 96,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                    children: lifestyleUser?.religion || "N/A"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 99,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                            lineNumber: 95,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                    children: "Children"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 104,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                    children: lifestyleUser?.children || "N/A"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 107,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                            lineNumber: 103,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                    children: "Pets"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 112,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                    children: lifestyleUser?.pets || "N/A"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 115,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                            lineNumber: 111,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                    children: "Employment Status"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 120,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                    children: lifestyleUser?.employmentStatus || "N/A"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 123,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                            lineNumber: 119,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-span-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                    children: "Education"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 128,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                    children: lifestyleUser?.education || "N/A"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                    lineNumber: 131,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                            lineNumber: 127,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                    lineNumber: 70,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                lineNumber: 67,
                columnNumber: 7
            }, this),
            membership !== "Standard Membership" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    lifestyleUser?.haveBusiness && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-16",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-xl font-semibold mb-6",
                                children: "My Business"
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                lineNumber: 142,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 gap-y-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "col-span-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                                children: "Industry"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                                lineNumber: 145,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$constants$2f$industry$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getIndustryLabel"])(lifestyleUser?.industry)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                                lineNumber: 148,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                        lineNumber: 144,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "col-span-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-[#344054] font-sans font-semibold text-[18px] leading-[22.32px] mb-1",
                                                children: "Company Name"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                                lineNumber: 153,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[#475467] font-sans text-[18px] font-normal leading-[30px]",
                                                children: lifestyleUser?.companyName || "N/A"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                                lineNumber: 156,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                        lineNumber: 152,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                lineNumber: 143,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                        lineNumber: 141,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-16",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-xl font-semibold mb-6",
                                children: "Description of Services"
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                lineNumber: 166,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                placeholder: "Please share here..",
                                value: lifestyleUser?.serviceDes || "",
                                readOnly: true,
                                className: "w-full min-h-[120px] p-3 bg-gray-100 border border-gray-300 rounded-lg text-[#475467] font-sans text-[16px] resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                lineNumber: 169,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                        lineNumber: 165,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-16",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-[18px] font-semibold mb-3 font-sans",
                                children: "Visit us online"
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                lineNumber: 179,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-row",
                                children: [
                                    lifestyleUser?.facebook && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "https://www.facebook.com/",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mr-[55px] cursor-pointer underline text-primary font-sans font-medium text-[18px]",
                                            children: "Facebook"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                            lineNumber: 189,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                        lineNumber: 184,
                                        columnNumber: 17
                                    }, this),
                                    lifestyleUser?.instagram && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "https://www.instagram.com",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mr-[55px] cursor-pointer underline text-primary font-sans font-medium text-[18px]",
                                            children: "Instagram"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                            lineNumber: 200,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                        lineNumber: 195,
                                        columnNumber: 17
                                    }, this),
                                    lifestyleUser?.linkedin && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "https://linkedin.com",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mr-[55px] cursor-pointer underline text-primary font-sans font-medium text-[18px]",
                                            children: "Linkedin"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                            lineNumber: 212,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                        lineNumber: 207,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                lineNumber: 182,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-6",
                                children: [
                                    lifestyleUser?.youtube && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "https://www.youtube.com",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mr-[55px] cursor-pointer underline text-primary font-sans font-medium text-[18px]",
                                            children: "Youtube"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                            lineNumber: 225,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                        lineNumber: 220,
                                        columnNumber: 17
                                    }, this),
                                    lifestyleUser?.website && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: lifestyleUser.website,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mr-[55px] cursor-pointer underline text-primary font-sans font-medium text-[18px]",
                                            children: "Website"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                            lineNumber: 237,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                        lineNumber: 232,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                                lineNumber: 218,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                        lineNumber: 178,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
                lineNumber: 138,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/profileDetails/ProfLifeStyleView.tsx",
        lineNumber: 65,
        columnNumber: 5
    }, this);
};
_s(ProfLifeStyleView, "UJZUJ5TyIAVZ3BFJBRusJ4bL7ok=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$lifeCicleApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetLifestyleUserQuery"]
    ];
});
_c = ProfLifeStyleView;
var _c;
__turbopack_refresh__.register(_c, "ProfLifeStyleView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/redux/Api/myTopApi.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "useGetMyTopQuery": (()=>useGetMyTopQuery),
    "useGetProfMyTopViewQuery": (()=>useGetProfMyTopViewQuery),
    "useGetSingleMyTopQuery": (()=>useGetSingleMyTopQuery),
    "useMytopAddMutation": (()=>useMytopAddMutation),
    "useMytopUpdataMutation": (()=>useMytopUpdataMutation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/baseApi.ts [app-client] (ecmascript)");
;
const myTopApi = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].injectEndpoints({
    endpoints: (build)=>({
            mytopAdd: build.mutation({
                query: (data)=>{
                    return {
                        url: "/selection/create",
                        method: "POST",
                        body: data
                    };
                },
                invalidatesTags: [
                    "MyTop"
                ]
            }),
            getMyTop: build.query({
                query: ()=>{
                    return {
                        url: "selection/get-my",
                        method: "GET"
                    };
                },
                providesTags: [
                    "MyTop"
                ]
            }),
            getSingleMyTop: build.query({
                query: (id)=>{
                    return {
                        url: `selection/user/${id}`,
                        method: "GET"
                    };
                },
                providesTags: [
                    "MyTop"
                ]
            }),
            getProfMyTopView: build.query({
                query: (id)=>({
                        url: `/selection/user/${id}`,
                        method: "GET"
                    }),
                providesTags: [
                    "MyTop"
                ]
            }),
            mytopUpdata: build.mutation({
                query: ({ formdata, id })=>({
                        url: `/selection/${id}`,
                        method: "PUT",
                        body: formdata
                    }),
                invalidatesTags: [
                    "MyTop"
                ]
            })
        })
});
const { useMytopAddMutation, useGetMyTopQuery, useGetProfMyTopViewQuery, useMytopUpdataMutation, useGetSingleMyTopQuery } = myTopApi;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/profileDetails/ProfMyTopView.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "ProfMyTopView": (()=>ProfMyTopView)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$LifeStyleViwLoder$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/userProfile/LifeStyleViwLoder.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$myTopApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/myTopApi.ts [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
const ProfMyTopView = ()=>{
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const { data, isLoading, isError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$myTopApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetProfMyTopViewQuery"])(id);
    const myTopData = data?.data?.[0];
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container my-16",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$LifeStyleViwLoder$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LifeStyleViwLoder"], {}, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
            lineNumber: 34,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
        lineNumber: 33,
        columnNumber: 7
    }, this);
    if (isError) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: "Error loading data."
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
        lineNumber: 37,
        columnNumber: 23
    }, this);
    const categories = [
        {
            title: "Personality",
            items: myTopData?.personality || []
        },
        {
            title: "Philosophies",
            items: myTopData?.philosophies || []
        },
        {
            title: "Goals",
            items: myTopData?.goals || []
        },
        {
            title: "Hobbies",
            items: myTopData?.hobbies || []
        },
        {
            title: "Social Groups",
            items: myTopData?.socialGroups || []
        },
        {
            title: "Foodie Fan",
            items: myTopData?.foodieFan || []
        },
        {
            title: "Musical Tastes",
            items: myTopData?.musicalTastes || []
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-16",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "",
                    children: categories.map((category, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "border border-gray-300 rounded-lg p-4 bg-white shadow-sm mb-3 w-[35%] m-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-[18px] sm:text-[20px] md:text-[22px] font-sans font-semibold mb-2 text-center",
                                    children: category.title
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
                                    lineNumber: 65,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "flex flex-wrap gap-1 text-gray-600",
                                    children: category.items.map((item, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            className: "text-center text-[16px] sm:text-[18px] md:text-[18px] text-[#475467] font-normal font-sans",
                                            children: item
                                        }, idx, false, {
                                            fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
                                            lineNumber: 70,
                                            columnNumber: 21
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
                                    lineNumber: 68,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
                            lineNumber: 61,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
                    lineNumber: 59,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
                lineNumber: 55,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
            lineNumber: 54,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfMyTopView.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
};
_s(ProfMyTopView, "aQTzIKG3wj9BxlwWx6VhmEaXKd0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$myTopApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetProfMyTopViewQuery"]
    ];
});
_c = ProfMyTopView;
var _c;
__turbopack_refresh__.register(_c, "ProfMyTopView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/redux/Api/talkingPointsApi.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "useGetProfTalkingPointsQuery": (()=>useGetProfTalkingPointsQuery),
    "useGetTalkingPointsQuery": (()=>useGetTalkingPointsQuery),
    "useTalkingPointsMutation": (()=>useTalkingPointsMutation),
    "useTalkingPointsUpdaMutation": (()=>useTalkingPointsUpdaMutation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/baseApi.ts [app-client] (ecmascript)");
;
const userApi = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$baseApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].injectEndpoints({
    endpoints: (build)=>({
            talkingPoints: build.mutation({
                query: (data)=>{
                    return {
                        url: "/takingPoint/create",
                        method: "POST",
                        body: data
                    };
                },
                invalidatesTags: [
                    "TalkingPoints"
                ]
            }),
            getTalkingPoints: build.query({
                query: ()=>{
                    return {
                        url: "/takingPoint/get-my-taking",
                        method: "GET"
                    };
                },
                providesTags: [
                    "TalkingPoints"
                ]
            }),
            getProfTalkingPoints: build.query({
                query: (id)=>{
                    return {
                        url: `/takingPoint/user/${id}`,
                        method: "GET"
                    };
                },
                providesTags: [
                    "TalkingPoints"
                ]
            }),
            talkingPointsUpda: build.mutation({
                query: ({ formdata, id })=>{
                    return {
                        url: `/takingPoint/${id}`,
                        method: "PUT",
                        body: formdata
                    };
                },
                invalidatesTags: [
                    "TalkingPoints"
                ]
            })
        })
});
const { useTalkingPointsMutation, useGetTalkingPointsQuery, useGetProfTalkingPointsQuery, useTalkingPointsUpdaMutation } = userApi;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/profileDetails/ProfTalkingPointsView.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "ProfTalkingPointsView": (()=>ProfTalkingPointsView)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$talkingPointsApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/redux/Api/talkingPointsApi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$DestinationLoader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/userProfile/DestinationLoader.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
const ProfTalkingPointsView = ()=>{
    _s();
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const { data, isLoading, isError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$talkingPointsApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetProfTalkingPointsQuery"])(id || "");
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container my-16",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$userProfile$2f$DestinationLoader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DestinationLoader"], {}, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
            lineNumber: 15,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
        lineNumber: 14,
        columnNumber: 7
    }, this);
    if (isError) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: "Error loading data."
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
        lineNumber: 18,
        columnNumber: 23
    }, this);
    if (!data) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center mt-10 ",
        children: "No data available."
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
        lineNumber: 20,
        columnNumber: 12
    }, this);
    const talkingPointsData = data.data?.[0];
    // Extract the talking points data
    // Array of questions to display dynamically from the API response
    const questionsAndAnswers = [
        {
            question: "How would you rate your level of cleanliness?",
            answer: talkingPointsData?.cleanlinessLevel || "N/A"
        },
        {
            question: "How would you describe your approach to cooking?",
            answer: talkingPointsData?.cookingHabit || "N/A"
        },
        {
            question: "How would you describe your relationship with a housemate?",
            answer: talkingPointsData?.houseMateRelation || "N/A"
        },
        {
            question: "How often do you host friends or gatherings?",
            answer: talkingPointsData?.hostFriend || "N/A"
        },
        {
            question: "What's your sleep schedule?",
            answer: talkingPointsData?.sleepSchedule || "N/A"
        },
        {
            question: "How often do you use tobacco or vaping products?",
            answer: talkingPointsData?.vapingProduct || "N/A"
        },
        {
            question: "How would you describe your financial habits?",
            answer: talkingPointsData?.financialHabit || "N/A"
        },
        {
            question: "How would you describe your style of communication?",
            answer: talkingPointsData?.communicationStyle || "N/A"
        },
        {
            question: "Are you pet friendly?",
            answer: talkingPointsData?.petFriendlyDescription || "N/A"
        },
        {
            question: "What's your typical work routine?",
            answer: talkingPointsData?.workRoutine || "N/A"
        },
        {
            question: "How often do you consume alcohol?",
            answer: talkingPointsData?.consumeAlcohol || "N/A"
        },
        {
            question: "How would you describe your use of drugs?",
            answer: talkingPointsData?.drugDescription || "N/A"
        },
        // { question: "Are you open to providing screening reports to potential housemates?", answer: talkingPointsData?.screeningReports || "N/A" },
        {
            question: "Are you open to having conversations regarding health matters (physical, mental)?",
            answer: talkingPointsData?.regardingHealth || "N/A"
        },
        {
            question: "Are you open to having conversations regarding health matters (physical, mental)?",
            answer: talkingPointsData?.politicalValues || "N/A"
        },
        {
            question: "How would you describe your Religious/Spiritual beliefs and practices?",
            answer: talkingPointsData?.relagiouseDescription || "N/A"
        },
        {
            question: "Do you have any allergies? If so, please list them here: (Ex., Airborne allergens, Foods, Nuts, Latex, Pets/Animals, Insects, etc.)",
            answer: talkingPointsData?.haveAllergies || "N/A"
        },
        {
            question: "Anything else?",
            answer: talkingPointsData?.anyThingElse || "N/A"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto py- font-sans",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
            children: questionsAndAnswers.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: `border border-gray-300 rounded-lg p-4 bg-white shadow-sm mb-3 ${index >= questionsAndAnswers.length - 3 ? "col-span-full" : ""}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "font-semibold text-[16px] sm:text-[18px] text-[#344054] mb-3",
                            children: item.question
                        }, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
                            lineNumber: 116,
                            columnNumber: 13
                        }, this),
                        index >= questionsAndAnswers.length - 3 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            readOnly: true,
                            value: item.answer,
                            className: "w-full text-[16px] sm:text-[18px] outline-none border border-slate-200 text-[#475467] bg-gray-100 p-3 rounded-lg"
                        }, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
                            lineNumber: 120,
                            columnNumber: 15
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[16px] sm:text-[18px] text-[#475467] bg-gray-100 p-3 rounded-lg",
                            children: item.answer
                        }, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
                            lineNumber: 126,
                            columnNumber: 15
                        }, this)
                    ]
                }, index, true, {
                    fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
                    lineNumber: 110,
                    columnNumber: 11
                }, this))
        }, void 0, false, {
            fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
            lineNumber: 108,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/profileDetails/ProfTalkingPointsView.tsx",
        lineNumber: 104,
        columnNumber: 5
    }, this);
};
_s(ProfTalkingPointsView, "FxzCxs3FGx+tpC+EIfcTgODC/rY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$redux$2f$Api$2f$talkingPointsApi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGetProfTalkingPointsQuery"]
    ];
});
_c = ProfTalkingPointsView;
var _c;
__turbopack_refresh__.register(_c, "ProfTalkingPointsView");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/profileDetails/ProfileDetails.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>ProfileDetails)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfDetialsDest$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/profileDetails/ProfDetialsDest.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfileDetailsView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/profileDetails/ProfileDetailsView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfLifeStyleView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/profileDetails/ProfLifeStyleView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfMyTopView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/profileDetails/ProfMyTopView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfTalkingPointsView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/components/profileDetails/ProfTalkingPointsView.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@radix-ui/react-tabs/dist/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function ProfileDetails() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "container mx-auto mt-[130px] md:mt-[180px]",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfileDetailsView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfileDetailsView"], {}, void 0, false, {
                fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Root, {
                className: "w-full mt-16",
                defaultValue: "tab1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.List, {
                        className: "flex justify-around border-b mb-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Trigger, {
                                className: "text-[#1D2939] text-2xl lg:text-[32px] font-semibold p-2 px-4 border-b-2 data-[state=active]:border-blue-500",
                                value: "destination",
                                defaultChecked: true,
                                children: "My Destinations"
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                                lineNumber: 16,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Trigger, {
                                className: "text-[#1D2939] text-2xl lg:text-[32px] font-semibold p-2 px-4 border-b-2 data-[state=active]:border-blue-500",
                                value: "lifestyle",
                                children: "Lifestyle"
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                                lineNumber: 23,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Trigger, {
                                className: "text-[#1D2939] text-2xl lg:text-[32px] font-semibold p-2 px-4 border-b-2 data-[state=active]:border-blue-500",
                                value: "top3",
                                children: "My Top 3's"
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Trigger, {
                                className: "text-[#1D2939] text-2xl lg:text-[32px] font-semibold p-2 px-4 border-b-2 data-[state=active]:border-blue-500",
                                value: "talkingpoints",
                                children: "Talking Points"
                            }, void 0, false, {
                                fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                                lineNumber: 35,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                        lineNumber: 15,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content, {
                        className: "p-4",
                        value: "destination",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfDetialsDest$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfDetailsDest"], {}, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                            lineNumber: 43,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content, {
                        className: "p-4",
                        value: "top3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfMyTopView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfMyTopView"], {}, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content, {
                        className: "p-4",
                        value: "lifestyle",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfLifeStyleView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfLifeStyleView"], {}, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tabs$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__.Content, {
                        className: "p-4",
                        value: "talkingpoints",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$profileDetails$2f$ProfTalkingPointsView$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProfTalkingPointsView"], {}, void 0, false, {
                            fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                            lineNumber: 52,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                        lineNumber: 51,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/profileDetails/ProfileDetails.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
_c = ProfileDetails;
var _c;
__turbopack_refresh__.register(_c, "ProfileDetails");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(default)/profile-details/[id]/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=src_195cd0._.js.map