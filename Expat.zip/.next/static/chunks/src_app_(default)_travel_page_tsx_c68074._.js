(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(default)_travel_page_tsx_c68074._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(default)_travel_page_tsx_c68074._.js",
  "chunks": [
    "static/chunks/_c039b7._.js",
    "static/chunks/node_modules_abe3db._.js"
  ],
  "source": "dynamic"
});
