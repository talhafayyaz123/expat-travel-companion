(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(default)_layout_tsx_5af7ab._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(default)_layout_tsx_5af7ab._.js",
  "chunks": [
    "static/chunks/src_ab98ac._.js",
    "static/chunks/node_modules_next_603616._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_5432f6._.js"
  ],
  "source": "dynamic"
});
