(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(dashbordLayout)_dashboard_admin_blogs_page_tsx_564e0e._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(dashbordLayout)_dashboard_admin_blogs_page_tsx_564e0e._.js",
  "chunks": [
    "static/chunks/src_712704._.js",
    "static/chunks/node_modules_react-icons_lia_index_mjs_8eda93._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3._.js",
    "static/chunks/node_modules_react-icons_md_index_mjs_78df2b._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_0f7fb9._.js"
  ],
  "source": "dynamic"
});
