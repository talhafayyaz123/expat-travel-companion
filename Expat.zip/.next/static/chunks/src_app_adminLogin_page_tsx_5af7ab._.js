(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_adminLogin_page_tsx_5af7ab._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_adminLogin_page_tsx_5af7ab._.js",
  "chunks": [
    "static/chunks/node_modules_64e91b._.js",
    "static/chunks/src_b4996e._.js"
  ],
  "source": "dynamic"
});
