(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(default)_user-profile_page_tsx_c68074._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(default)_user-profile_page_tsx_c68074._.js",
  "chunks": [
    "static/chunks/src_225cb2._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760a._.js",
    "static/chunks/node_modules_framer-motion_dist_es_d5246a._.js",
    "static/chunks/node_modules_antd_es_42c6ed._.js",
    "static/chunks/node_modules_@ant-design_cssinjs_es_e20869._.js",
    "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856._.js",
    "static/chunks/node_modules_b3ed00._.js"
  ],
  "source": "dynamic"
});
