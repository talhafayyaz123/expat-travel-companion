
import OtpPage from '@/components/otppage/OtpPage';
import React from 'react';
const page = () => {
    return (
        <div>
        <OtpPage></OtpPage>
        </div>
    );
};

export default page;