import React from 'react';
import ForgotPassword from '@/components/forgotpassword/ForgotPassword';

const page = () => {
    return (
        <div>
          <ForgotPassword></ForgotPassword>
        </div>
    );
};

export default page;