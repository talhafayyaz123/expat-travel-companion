
import LoginPage from '@/components/login/LoginPage';

const page = () => {
    return (
        <div>
            <LoginPage></LoginPage>
        </div>
    );
};

export default page;