
import React from 'react'

const UpdateBlogpage = () => {
  return (
    <div>
      
    </div>
  )
}

export default UpdateBlogpage
