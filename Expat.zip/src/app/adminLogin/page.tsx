import AdminLogin from "@/components/admin/AdminLogin";
import React from "react";

export default function page() {
  return (
    <div>
      <AdminLogin />
    </div>
  );
}
