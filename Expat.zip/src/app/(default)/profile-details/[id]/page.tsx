import ProfileDetails from '@/components/profileDetails/ProfileDetails';
import React from 'react';

const page = () => {

     
    return (
        <div>
            <ProfileDetails/>
        
        </div>
    );
};

export default page;