import HelpAndSupport from "@/components/home/HelpAndSupport";
import HeaderWithoutBorder from "@/components/home/PageReusable/HeaderWithoutBorder";
import Link from "next/link";
import React from "react";

const Page = () => {
  return (
    <HelpAndSupport/>
  );
};

export default Page;
