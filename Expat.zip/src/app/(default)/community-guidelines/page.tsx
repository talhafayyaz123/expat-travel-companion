// pages/community-guidelines.tsx

import CommunityGuidelines from "@/components/home/CommunityGuidelines";
import HeaderWithoutBorder from "@/components/home/PageReusable/HeaderWithoutBorder";

const page = () => {
  return (
    <CommunityGuidelines/>
  );
};

export default page;
