import Liability from "@/components/home/Liability";


const page = () => {
  return (
    <Liability/>
  );
}

export default page
