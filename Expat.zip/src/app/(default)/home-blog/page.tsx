import BlogList from '@/components/home-blog/BlogList'
import React from 'react'

export default function page() {
  return (
    <div>
        <BlogList/>
    </div>
  )
}
