import BlogHomeDetails from "@/components/home-blog/BlogHomeDetails";
import React from "react";

export default function Page() {
  return (
    <div>
      <BlogHomeDetails />
    </div>
  );
}
