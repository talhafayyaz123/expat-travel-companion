import TermsAndCondition from "@/components/home/TermsAndCondition";


const TermsAndConditionPage = () => {
  return (
    <TermsAndCondition/>
  );
};

export default TermsAndConditionPage;
