import UserProfile from "@/components/userProfile/UserProfile";
import React from "react";

const page = () => {
  return (
    <div>
      <UserProfile></UserProfile>
    </div>
  );
};

export default page;
