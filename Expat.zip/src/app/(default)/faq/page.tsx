import HomeFaq from '@/components/home/homeFaq/HomeFaq'
import React from 'react'

export default function Faq()  {
  return (
    <div>
        <HomeFaq/>
    </div>
  )
}
