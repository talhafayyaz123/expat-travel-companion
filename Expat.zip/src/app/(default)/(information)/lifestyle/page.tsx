"use client"

import LifeStyle from "@/components/lifeStyle/LifeStyle";

const page = () => {
  return (
    <div className="">
               <LifeStyle/>

    
    </div>
  );
};

export default page;
