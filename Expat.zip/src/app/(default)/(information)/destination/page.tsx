"use client"

import Destination from "@/components/destination/Destination";

const page = () => {
  return (
    <div className="">
               
            <Destination/>

    
    </div>
  );
};

export default page;
