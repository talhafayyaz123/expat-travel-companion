"use client"
import ProfileForm from "@/components/profileform/ProfileForm";

const page = () => {
  return (
    <div className="">
               
       <ProfileForm/>

    
    </div>
  );
};

export default page;
