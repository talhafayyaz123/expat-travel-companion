"use client"

import MyTop from "@/components/myTop/MyTop3";


const page = () => {
  return (
    <div className="">
               <MyTop/>

    
    </div>
  );
};

export default page;
