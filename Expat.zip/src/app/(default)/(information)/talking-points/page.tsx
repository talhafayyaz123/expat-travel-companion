"use client"

import TalkingPoints from "@/components/talkingPoints/TalkingPoints";



const page = () => {
  return (
    <div className="">
        <TalkingPoints/>

    
    </div>
  );
};

export default page;
