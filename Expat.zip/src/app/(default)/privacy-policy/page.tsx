import PrivacyAndPolicy from "@/components/home/PrivacyAndPolicy";

const PrivacyPage = () => {
  return <PrivacyAndPolicy />;
};

export default PrivacyPage;
