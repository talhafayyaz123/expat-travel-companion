import SavedProfiles from "@/components/savedProfile/SavedProfiles";
import React from "react";

const page = () => {
  return (
    <div>
      <SavedProfiles></SavedProfiles>
    </div>
  );
};

export default page;
