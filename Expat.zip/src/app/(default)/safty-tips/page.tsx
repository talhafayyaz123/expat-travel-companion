import SaftyTips from "@/components/home/SaftyTips";


const page = () => {
  return (
    <SaftyTips/>
  );
};

export default page;
