import Services from '@/components/home/services/Services'
import React from 'react'

const ServicesPage = () => {
  return (
    <div>
      <Services/>
    </div>
  )
}

export default ServicesPage
